package com.example.mylogin;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class AdminPaymentAdapter extends RecyclerView.Adapter<AdminPaymentAdapter.PaymentViewHolder> {

    private final List<payment> paymentList;
    private final Context context;
    private final boolean showReminderButton;

    public AdminPaymentAdapter(List<payment> paymentList, Context context, boolean showReminderButton) {
        this.paymentList = paymentList;
        this.context = context;
        this.showReminderButton = showReminderButton;
    }

    @NonNull
    @Override
    public PaymentViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_admin_payment, parent, false);
        return new PaymentViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PaymentViewHolder holder, int position) {
        payment pay = paymentList.get(position);

        holder.tvUsername.setText("Name: " + pay.getUsername());
        holder.tvConsumerNumber.setText("Consumer Number: " + pay.getConsumerNumber());
        holder.tvPhoneNumber.setText("Phone: " + pay.getPhoneNumber());
        holder.tvBillAmount.setText("Amount: " + pay.getBillAmount());
        holder.tvStatus.setText("Status: " + pay.getStatus());
        holder.tvBillDate.setText("Bill Date: " + (pay.getBillDate().isEmpty() ? "Not Paid" : pay.getBillDate()));

        if (showReminderButton) {
            holder.btnReminder.setVisibility(View.VISIBLE);
            holder.btnReminder.setOnClickListener(v -> sendReminder(pay));
        } else {
            holder.btnReminder.setVisibility(View.GONE);
        }
    }

    @Override
    public int getItemCount() {
        return paymentList.size();
    }

    public static class PaymentViewHolder extends RecyclerView.ViewHolder {
        TextView tvUsername, tvConsumerNumber, tvPhoneNumber, tvBillAmount, tvStatus, tvBillDate;
        Button btnReminder;

        public PaymentViewHolder(@NonNull View itemView) {
            super(itemView);
            tvUsername = itemView.findViewById(R.id.tvUsername);
            tvConsumerNumber = itemView.findViewById(R.id.tvConsumerNumber);
            tvPhoneNumber = itemView.findViewById(R.id.tvPhoneNumber);
            tvBillAmount = itemView.findViewById(R.id.tvBillAmount);
            tvStatus = itemView.findViewById(R.id.tvStatus);
            tvBillDate = itemView.findViewById(R.id.tvBillDate);
            btnReminder = itemView.findViewById(R.id.btnReminder);
        }
    }

    private void sendReminder(payment pay) {
        if (pay.getPhoneNumber() == null || pay.getPhoneNumber().isEmpty()) return;

        String message = "Hello " + pay.getUsername() + ",\n"
                + "Your water bill (Consumer No: " + pay.getConsumerNumber() + ") is pending.\n"
                + "Amount: " + pay.getBillAmount() + "\n"
                + "Please pay as soon as possible.";

        // WhatsApp intent
        Intent whatsappIntent = new Intent(Intent.ACTION_VIEW);
        String url = "https://api.whatsapp.com/send?phone=" + pay.getPhoneNumber() + "&text=" + Uri.encode(message);
        whatsappIntent.setPackage("com.whatsapp"); // make it explicit
        whatsappIntent.setData(Uri.parse(url));

        // SMS intent
        Intent smsIntent = new Intent(Intent.ACTION_SENDTO);
        smsIntent.setData(Uri.parse("smsto:" + pay.getPhoneNumber())); // only SMS apps will handle this
        smsIntent.putExtra("sms_body", message);

        // chooser with both intents
        Intent chooser = Intent.createChooser(smsIntent, "Send Reminder via");
        chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{whatsappIntent});

        context.startActivity(chooser);
    }
}
