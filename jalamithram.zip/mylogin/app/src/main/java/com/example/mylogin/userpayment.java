//package com.example.userpayment;
//
//import android.app.Activity;
//import android.content.Intent;
//import android.graphics.Bitmap;
//import android.net.Uri;
//import android.os.Bundle;
//import android.provider.MediaStore;
//import android.widget.Button;
//import android.widget.ImageView;
//import android.widget.TextView;
//import android.widget.Toast;
//
//import androidx.annotation.Nullable;
//import androidx.appcompat.app.AppCompatActivity;
//
//import com.example.mylogin.R;
//import com.google.mlkit.vision.common.InputImage;
//import com.google.mlkit.vision.text.Text;
//import com.google.mlkit.vision.text.TextRecognition;
//import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
//
//import java.io.IOException;
//import java.util.regex.Matcher;
//import java.util.regex.Pattern;
//
//public class userpayment extends AppCompatActivity {
//
//    private static final int PICK_IMAGE_REQUEST = 1;
//
//    private Button buttonUploadMeterImage, buttonPay;
//    private ImageView imageMeter;
//    private TextView textMeterReading, textBillAmount, textPaymentStatus;
//
//    private Uri meterImageUri;
//    private int meterReading = 0;
//    private double billAmount = 0.0;
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_userpayment);
//
//        // Initialize views
//        buttonUploadMeterImage = findViewById(R.id.buttonUploadMeterImage);
//        buttonPay = findViewById(R.id.buttonPay);
//        imageMeter = findViewById(R.id.imageMeter);
//        textMeterReading = findViewById(R.id.textMeterReading);
//        textBillAmount = findViewById(R.id.textBillAmount);
//        textPaymentStatus = findViewById(R.id.textPaymentStatus);
//
//        // Upload meter image button
//        buttonUploadMeterImage.setOnClickListener(v -> openFileChooser());
//
//        // Pay button
//        buttonPay.setOnClickListener(v -> {
//            if (billAmount > 0) {
//                textPaymentStatus.setText("Status: Paid");
//                Toast.makeText(this, "Payment Successful! ₹" + billAmount, Toast.LENGTH_SHORT).show();
//            } else {
//                Toast.makeText(this, "Please upload meter image first.", Toast.LENGTH_SHORT).show();
//            }
//        });
//    }
//
//    private void openFileChooser() {
//        Intent intent = new Intent();
//        intent.setType("image/*");
//        intent.setAction(Intent.ACTION_GET_CONTENT);
//        startActivityForResult(Intent.createChooser(intent, "Select Meter Image"), PICK_IMAGE_REQUEST);
//    }
//
//    @Override
//    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
//        super.onActivityResult(requestCode, resultCode, data);
//
//        if (requestCode == PICK_IMAGE_REQUEST && resultCode == Activity.RESULT_OK
//                && data != null && data.getData() != null) {
//            meterImageUri = data.getData();
//
//            try {
//                Bitmap bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), meterImageUri);
//                imageMeter.setImageBitmap(bitmap);
//                extractMeterReading(bitmap);
//            } catch (IOException e) {
//                e.printStackTrace();
//            }
//        }
//    }
//
//    // OCR using ML Kit
//    private void extractMeterReading(Bitmap bitmap) {
//        InputImage image = InputImage.fromBitmap(bitmap, 0);
//        com.google.mlkit.vision.text.TextRecognizer recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
//
//        recognizer.process(image)
//                .addOnSuccessListener(text -> {
//                    meterReading = parseMeterReading(text.getText());
//                    textMeterReading.setText("Meter Reading: " + meterReading);
//                    calculateBill();
//                })
//                .addOnFailureListener(e -> Toast.makeText(this, "Failed to read meter", Toast.LENGTH_SHORT).show());
//    }
//
//    // Extract digits from OCR text
//    private int parseMeterReading(String ocrText) {
//        Pattern p = Pattern.compile("\\d+");
//        Matcher m = p.matcher(ocrText);
//        int maxValue = 0;
//        while (m.find()) {
//            int value = Integer.parseInt(m.group());
//            if (value > maxValue) maxValue = value;
//        }
//        return maxValue;
//    }
//
//    // Calculate water bill
//    private void calculateBill() {
//        // Example calculation: ₹5 per unit
//        billAmount = meterReading * 5.0;
//        textBillAmount.setText("Bill Amount: ₹" + String.format("%.2f", billAmount));
//        textPaymentStatus.setText("Status: Pending");
//    }
//}
