//package com.example.mylogin;
//
//public class connectionclass {
//    protected static String db="sampledb";
//    protected static String ip="10.0.2.2";
//    protected static String port="3306";
//
//    protected static String username="root";
//    protected static String password="swsr@2003";
//
//}
