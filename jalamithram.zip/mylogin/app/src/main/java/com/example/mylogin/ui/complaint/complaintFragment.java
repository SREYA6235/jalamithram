package com.example.mylogin.ui.complaint;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.example.mylogin.R;

public class complaintFragment extends Fragment {

    private static final int PICK_IMAGE_REQUEST = 1; // request code for image selection
    private Button buttonUploadProof;
    private TextView textViewProofStatus;
    private Uri selectedImageUri;

    public complaintFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_complaint, container, false);

        // Initialize views
        buttonUploadProof = view.findViewById(R.id.buttonUploadProof);
        textViewProofStatus = view.findViewById(R.id.textViewProofStatus);

        // Button click listener
        buttonUploadProof.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openFileChooser();
            }
        });

        return view;
    }

    // Open the file chooser to select image
    private void openFileChooser() {
        Intent intent = new Intent();
        intent.setType("image/*"); // only images
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Image"), PICK_IMAGE_REQUEST);
    }

    // Handle the result from image picker
    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == Activity.RESULT_OK
                && data != null && data.getData() != null) {
            selectedImageUri = data.getData(); // get selected image URI
            String fileName = getFileName(selectedImageUri);
            textViewProofStatus.setText(fileName); // update TextView
        }
    }

    // Helper method to get the file name from URI
    private String getFileName(Uri uri) {
        String result = "File selected";
        if (uri.getScheme().equals("content")) {
            android.database.Cursor cursor = getActivity().getContentResolver().query(uri, null, null, null, null);
            try {
                if (cursor != null && cursor.moveToFirst()) {
                    result = cursor.getString(cursor.getColumnIndexOrThrow(android.provider.OpenableColumns.DISPLAY_NAME));
                }
            } finally {
                if (cursor != null) cursor.close();
            }
        }
        if (result == null) {
            result = uri.getLastPathSegment();
        }
        return result;
    }
}
