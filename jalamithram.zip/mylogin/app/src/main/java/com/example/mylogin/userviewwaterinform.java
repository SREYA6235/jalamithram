package com.example.mylogin;



import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.List;

public class userviewwaterinform extends AppCompatActivity {

    private LinearLayout layoutAllSchedules;
    private FirebaseFirestore db;
    private List<waterinform> allWaterInfoList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_userviewwaterinform); // make sure layout file name matches
        layoutAllSchedules = findViewById(R.id.layoutAllSchedules);

        db = FirebaseFirestore.getInstance();
        allWaterInfoList = new ArrayList<>();

        loadAllSchedules();
    }

    private void loadAllSchedules() {
        CollectionReference collectionRef = db.collection("waterSchedules");

        collectionRef.get().addOnCompleteListener(task -> {
            if (task.isSuccessful() && task.getResult() != null) {
                layoutAllSchedules.removeAllViews();
                allWaterInfoList.clear();

                QuerySnapshot querySnapshot = task.getResult();

                for (QueryDocumentSnapshot doc : querySnapshot) {
                    waterinform info = doc.toObject(waterinform.class);
                    info.setId(doc.getId());
                    allWaterInfoList.add(info);
                    addScheduleCard(info);
                }

                if (allWaterInfoList.isEmpty()) {
                    showNoDataMessage();
                }
            } else {
                Toast.makeText(this, "Failed to load schedules", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void addScheduleCard(waterinform info) {
        // Create a container for each schedule
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(20, 20, 20, 20);
        card.setBackgroundResource(android.R.drawable.dialog_holo_light_frame);
        card.setElevation(5);

        // Area
        TextView textArea = new TextView(this);
        textArea.setText("Area: " + info.getArea());
        textArea.setTextSize(16f);
        textArea.setTextColor(getResources().getColor(android.R.color.black));

        // Date
        TextView textDate = new TextView(this);
        textDate.setText("Date: " + info.getDate());
        textDate.setTextColor(getResources().getColor(android.R.color.holo_blue_dark));

        // Arrival Time
        TextView textArrival = new TextView(this);
        textArrival.setText("Arrival Time: " + info.getArrivalTime());
        textArrival.setTextColor(getResources().getColor(android.R.color.holo_red_dark));

        // Closing Time
        TextView textClosing = new TextView(this);
        textClosing.setText("Closing Time: " + info.getClosingTime());
        textClosing.setTextColor(getResources().getColor(android.R.color.holo_red_dark));

        // Add all text views to the card
        card.addView(textArea);
        card.addView(textDate);
        card.addView(textArrival);
        card.addView(textClosing);

        // Add the card to main layout
        layoutAllSchedules.addView(card);
    }

    private void showNoDataMessage() {
        TextView noData = new TextView(this);
        noData.setText("No water schedules found.");
        noData.setTextSize(18f);
        noData.setTextColor(getResources().getColor(android.R.color.holo_red_dark));
        noData.setPadding(20, 40, 20, 20);
        layoutAllSchedules.addView(noData);
    }
}
