package com.example.mylogin;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class PaymentHistoryAdapter extends RecyclerView.Adapter<PaymentHistoryAdapter.ViewHolder> {

    private List<payment> paymentList;

    public PaymentHistoryAdapter(List<payment> paymentList) {
        this.paymentList = paymentList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_payment_history, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        payment bill = paymentList.get(position);
        holder.tvBillAmount.setText("₹" + bill.getBillAmount());
        holder.tvBillDate.setText("Bill Date: " + bill.getBillDate());
        holder.tvDueDate.setText("Due Date: " + bill.getDueDate());
        holder.tvStatus.setText("Status: " + bill.getStatus());
        holder.tvMeterReading.setText("Meter: " + bill.getMeterReading());
    }

    @Override
    public int getItemCount() {
        return paymentList.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvBillAmount, tvBillDate, tvDueDate, tvStatus, tvMeterReading;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvBillAmount = itemView.findViewById(R.id.tvBillAmount);
            tvBillDate = itemView.findViewById(R.id.tvBillDate);
            tvDueDate = itemView.findViewById(R.id.tvDueDate);
            tvStatus = itemView.findViewById(R.id.tvStatus);
            tvMeterReading = itemView.findViewById(R.id.tvMeterReading);
        }
    }
}
