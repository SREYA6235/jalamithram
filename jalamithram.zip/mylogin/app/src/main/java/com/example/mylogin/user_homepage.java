package com.example.mylogin;
import android.content.Intent;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class user_homepage extends AppCompatActivity {

    LinearLayout cardProfile, cardPayment, cardComplaints, cardSchedule, cardUpdates;
    LinearLayout cardHistory;

    String consumerNumber, phoneNumber, username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_homepage);

        // Initialize cards
        cardProfile = findViewById(R.id.cardProfile);
        cardPayment = findViewById(R.id.cardPayment);
        cardComplaints = findViewById(R.id.cardComplaints);
        cardSchedule = findViewById(R.id.cardSchedule);
        cardUpdates = findViewById(R.id.cardUpdates);
        cardHistory = findViewById(R.id.history);
        // ✅ Receive user details from login
        consumerNumber = getIntent().getStringExtra("consumerNumber");
        phoneNumber = getIntent().getStringExtra("phoneNumber");
        username = getIntent().getStringExtra("username");

        if (consumerNumber == null || phoneNumber == null) {
            Toast.makeText(this, "User details not found. Please log in again.", Toast.LENGTH_LONG).show();
            Intent backToLogin = new Intent(this, userlogin.class);
            startActivity(backToLogin);
            finish();
            return;
        }

        // ✅ Profile card
        cardProfile.setOnClickListener(v -> {
            Intent intent = new Intent(user_homepage.this, user_profile.class);
            intent.putExtra("consumerNumber", consumerNumber);
            intent.putExtra("phoneNumber", phoneNumber);
            intent.putExtra("username", username);
            startActivity(intent);
        });

        // ✅ Payment card
        cardPayment.setOnClickListener(v -> {
            Intent intent = new Intent(user_homepage.this, water_bill_payment.class);
            intent.putExtra("consumerNumber", consumerNumber);
            intent.putExtra("phoneNumber", phoneNumber);
            intent.putExtra("username", username);
            startActivity(intent);
        });

        // ✅ Complaints card
        cardComplaints.setOnClickListener(v -> {
            Intent intent = new Intent(user_homepage.this, user_complaint.class);
            intent.putExtra("consumerNumber", consumerNumber);
            intent.putExtra("phoneNumber", phoneNumber);
            intent.putExtra("username", username);
            startActivity(intent);
        });

        // ✅ Schedule card
        cardSchedule.setOnClickListener(v -> {
            Intent intent = new Intent(user_homepage.this, userviewwaterinform.class);
            intent.putExtra("consumerNumber", consumerNumber);
            intent.putExtra("phoneNumber", phoneNumber);
            intent.putExtra("username", username);
            startActivity(intent);
        });

        // ✅ Updates card
        cardUpdates.setOnClickListener(v -> {
            Intent intent = new Intent(user_homepage.this, activity_user_complaint_status.class);
            intent.putExtra("consumerNumber", consumerNumber);
            intent.putExtra("phoneNumber", phoneNumber);
            intent.putExtra("username", username);
            startActivity(intent);
        });
        cardHistory.setOnClickListener(v -> {
            Intent intent = new Intent(user_homepage.this, paymenthistory.class);
            intent.putExtra("consumerNumber", consumerNumber);
            intent.putExtra("phoneNumber", phoneNumber);
            intent.putExtra("username", username);
            startActivity(intent);
        });
    }
}
