package com.example.mylogin.ui.waterinform;


import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.mylogin.R;
import com.example.mylogin.ui.waterinform.waterinfo;

import java.util.ArrayList;

public class WaterAdapter extends RecyclerView.Adapter<WaterAdapter.ViewHolder> {

    private ArrayList<waterinfo> waterList;

    public WaterAdapter(ArrayList<waterinfo> waterList) {
        this.waterList = waterList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_water, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        waterinfo info = waterList.get(position);
        holder.textArea.setText("Area: " + info.getArea());
        holder.textDate.setText("Date: " + info.getDate());
        holder.textArrival.setText("Arrival: " + info.getArrivalTime());
        holder.textClosing.setText("Closing: " + info.getClosingTime());
    }

    @Override
    public int getItemCount() {
        return waterList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView textArea, textDate, textArrival, textClosing;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            textArea = itemView.findViewById(R.id.textArea);
            textDate = itemView.findViewById(R.id.textDate);
            textArrival = itemView.findViewById(R.id.textArrival);
            textClosing = itemView.findViewById(R.id.textClosing);
        }
    }
}
