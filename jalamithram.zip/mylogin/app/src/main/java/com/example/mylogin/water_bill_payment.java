package com.example.mylogin;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.firestore.FirebaseFirestore;
import com.razorpay.Checkout;
import com.razorpay.PaymentResultListener;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class water_bill_payment extends AppCompatActivity implements PaymentResultListener {

    private static final int CAMERA_REQUEST_CODE = 101;

    ImageView imgMeter;
    Button btnCaptureImage, btnPayBill;
    EditText edtMeterReading;
    TextView tvUsername, tvConsumerNumber, tvBillAmount, tvDueDate;

    Bitmap capturedImage = null;
    ProgressDialog progressDialog;

    DatabaseReference dbRef;
    FirebaseFirestore firestore;

    String username = "";
    String phoneNumber = "";
    String consumerNumber = "";
    String currentBillId = "";
    String billAmount = "";
    boolean isBpl = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_water_bill_payment);

        imgMeter = findViewById(R.id.imgMeter);
        btnCaptureImage = findViewById(R.id.btnCaptureImage);
        btnPayBill = findViewById(R.id.btnPayBill);
        edtMeterReading = findViewById(R.id.edtMeterReading);
        tvUsername = findViewById(R.id.tvUsername);
        tvConsumerNumber = findViewById(R.id.tvConsumerNumber);
        tvBillAmount = findViewById(R.id.tvBillAmount);
        tvDueDate = findViewById(R.id.tvDueDate);

        dbRef = FirebaseDatabase.getInstance().getReference("WaterBills");
        firestore = FirebaseFirestore.getInstance();
        progressDialog = new ProgressDialog(this);
        progressDialog.setCancelable(false);

        // ✅ Get data from intent or session
        phoneNumber = getIntent().getStringExtra("phoneNumber");
        consumerNumber = getIntent().getStringExtra("consumerNumber");
        username = getIntent().getStringExtra("username");

        if ((phoneNumber == null || consumerNumber == null) && UserSession.isLoggedIn()) {
            phoneNumber = UserSession.phoneNumber;
            consumerNumber = UserSession.consumerNumber;
            username = UserSession.username;
        }

        if (phoneNumber == null || consumerNumber == null) {
            Toast.makeText(this, "Login details missing. Please login again.", Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        tvUsername.setText("Username: " + username);
        tvConsumerNumber.setText("Consumer Number: " + consumerNumber);

        btnCaptureImage.setOnClickListener(v -> {
            Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            startActivityForResult(intent, CAMERA_REQUEST_CODE);
        });

        btnPayBill.setOnClickListener(v -> initiatePayment());
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CAMERA_REQUEST_CODE && resultCode == RESULT_OK && data != null) {
            capturedImage = (Bitmap) data.getExtras().get("data");
            imgMeter.setImageBitmap(capturedImage);
            edtMeterReading.setText(String.valueOf((int) (Math.random() * 100)));
            calculateBill();
        }
    }

    private void calculateBill() {
        try {
            int reading = Integer.parseInt(edtMeterReading.getText().toString());
            int amount = isBpl ? 15 : reading * 2;
            billAmount = String.valueOf(amount);
            tvBillAmount.setText("Bill Amount: ₹" + billAmount);

            Calendar cal = Calendar.getInstance();
            cal.add(Calendar.DAY_OF_MONTH, 7);
            String dueDate = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(cal.getTime());
            tvDueDate.setText("Due Date: " + dueDate);
        } catch (Exception e) {
            Toast.makeText(this, "Enter valid reading", Toast.LENGTH_SHORT).show();
        }
    }

    // ✅ Step 1: Initiate Razorpay payment
    private void initiatePayment() {
        if (billAmount.isEmpty()) {
            Toast.makeText(this, "Please calculate your bill first!", Toast.LENGTH_SHORT).show();
            return;
        }

        Checkout checkout = new Checkout();
        checkout.setKeyID("rzp_test_1DP5mmOlF5G5ag"); // 🔁 Replace with your Razorpay Test Key
        checkout.setImage(R.drawable.ic_launcher_foreground);

        try {
            JSONObject options = new JSONObject();
            options.put("name", "Water Supply Department");
            options.put("description", "Water Bill Payment");
            options.put("currency", "INR");
            double total = Double.parseDouble(billAmount);
            options.put("amount", total * 100); // Convert to paise

            JSONObject prefill = new JSONObject();
            prefill.put("contact", phoneNumber);
            prefill.put("email", "user@example.com");
            options.put("prefill", prefill);

            checkout.open(this, options);
        } catch (Exception e) {
            Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    // ✅ Step 2: Payment success → save bill
    @Override
    public void onPaymentSuccess(String razorpayPaymentId) {
        saveBillToDatabase("Paid", razorpayPaymentId);
    }

    // ✅ Step 3: Payment failed
    @Override
    public void onPaymentError(int code, String message) {
        Toast.makeText(this, "Payment failed: " + message, Toast.LENGTH_LONG).show();
    }

    // ✅ Step 4: Save bill in Realtime DB & update Firestore profile
    private void saveBillToDatabase(String status, String paymentId) {
        progressDialog.setMessage("Saving payment...");
        progressDialog.show();

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        if (capturedImage != null)
            capturedImage.compress(Bitmap.CompressFormat.JPEG, 80, baos);
        String encodedImage = Base64.encodeToString(baos.toByteArray(), Base64.DEFAULT);

        String reading = edtMeterReading.getText().toString().trim();
        String currentDate = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(Calendar.getInstance().getTime());
        String dueDate = tvDueDate.getText().toString().replace("Due Date: ", "");

        Map<String, Object> billData = new HashMap<>();
        billData.put("username", username);
        billData.put("phoneNumber", phoneNumber);
        billData.put("consumerNumber", consumerNumber);
        billData.put("meterReading", reading);
        billData.put("billAmount", billAmount);
        billData.put("billDate", currentDate);
        billData.put("dueDate", dueDate);
        billData.put("paymentId", paymentId);
        billData.put("meterImageBase64", encodedImage);
        billData.put("status", status);

        currentBillId = dbRef.push().getKey();
        dbRef.child(currentBillId).setValue(billData)
                .addOnSuccessListener(unused -> {
                    firestore.collection("UserProfiles")
                            .whereEqualTo("consumerNumber", consumerNumber)
                            .get()
                            .addOnSuccessListener(query -> {
                                if (!query.isEmpty()) {
                                    query.getDocuments().get(0).getReference().update("paymentStatus", "Paid");
                                }
                            });

                    progressDialog.dismiss();
                    Toast.makeText(this, "✅ Payment Successful!", Toast.LENGTH_LONG).show();
                })
                .addOnFailureListener(e -> {
                    progressDialog.dismiss();
                    Toast.makeText(this, "Error saving payment: " + e.getMessage(), Toast.LENGTH_LONG).show();
                });
    }
}
