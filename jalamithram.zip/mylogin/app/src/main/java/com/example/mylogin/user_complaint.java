package com.example.mylogin;
import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.mylogin.R;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.DocumentChange;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class user_complaint extends AppCompatActivity {

    private static final int REQUEST_CODE_GALLERY = 100;
    private static final int REQUEST_CODE_CAMERA = 101;

    Spinner spinnerComplaintType;
    EditText edtComplaint;
    Button btnChooseFile, btnSubmitComplaint;
    TextView tvFileName, tvConsumerNumber, tvUsername, tvAdminReply;
    Uri fileUri = null;

    FirebaseFirestore db;
    StorageReference storageReference;

    String consumerNumber, username;

    ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_complaint);

        // Initialize Firebase
        db = FirebaseFirestore.getInstance();
        storageReference = FirebaseStorage.getInstance().getReference("complaint_proofs");

        // Bind views
        spinnerComplaintType = findViewById(R.id.spinnerComplaintType);
        edtComplaint = findViewById(R.id.edtComplaint);
        btnChooseFile = findViewById(R.id.btnChooseFile);
        btnSubmitComplaint = findViewById(R.id.btnSubmitComplaint);
        tvFileName = findViewById(R.id.tvFileName);
        tvConsumerNumber = findViewById(R.id.tvConsumerNumber);
        tvUsername = findViewById(R.id.tvUsername);
        tvAdminReply = findViewById(R.id.tvAdminReply);

        progressDialog = new ProgressDialog(this);
        progressDialog.setCancelable(false);

        // Get consumer number from intent
        consumerNumber = getIntent().getStringExtra("consumerNumber");

        if (consumerNumber != null && !consumerNumber.isEmpty()) {
            tvConsumerNumber.setText("Consumer Number: " + consumerNumber);

            // 🔹 Fetch username from Firestore UserProfiles
            db.collection("UserProfiles")
                    .document(consumerNumber)
                    .get()
                    .addOnSuccessListener(doc -> {
                        if (doc.exists()) {
                            username = doc.getString("username");
                            if (username != null && !username.isEmpty()) {
                                tvUsername.setText("Username: " + username);
                            } else {
                                tvUsername.setText("Username: Unknown");
                            }
                        } else {
                            tvUsername.setText("Username: Unknown");
                        }
                    })
                    .addOnFailureListener(e -> tvUsername.setText("Username: Unknown"));
        } else {
            tvConsumerNumber.setText("Consumer Number: -");
            tvUsername.setText("Username: -");
        }

        // Populate spinner
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item,
                new String[]{"Select Complaint Type", "Water Leakage", "High Bill", "No Water Supply", "Meter Issue", "Others"});
        spinnerComplaintType.setAdapter(adapter);

        // File chooser button (Camera or Gallery)
        btnChooseFile.setOnClickListener(v -> showFilePickerOptions());

        // Submit complaint
        btnSubmitComplaint.setOnClickListener(v -> submitComplaint());

        // Listen to latest admin reply
        listenLatestAdminReply();
    }

    private void showFilePickerOptions() {
        // Open chooser dialog for camera or gallery
        String[] options = {"Camera", "Gallery"};
        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        builder.setTitle("Select Proof From");
        builder.setItems(options, (dialog, which) -> {
            if (which == 0) { // Camera
                Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(cameraIntent, REQUEST_CODE_CAMERA);
            } else { // Gallery
                Intent galleryIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(galleryIntent, REQUEST_CODE_GALLERY);
            }
        });
        builder.show();
    }

    private void submitComplaint() {
        String complaintType = spinnerComplaintType.getSelectedItem().toString();
        String complaintText = edtComplaint.getText().toString().trim();

        if (complaintType.equals("Select Complaint Type")) {
            Toast.makeText(this, "Please select a complaint type", Toast.LENGTH_SHORT).show();
            return;
        }

        if (complaintText.isEmpty()) {
            complaintText = "No description provided";
        }

        progressDialog.setMessage("Submitting complaint...");
        progressDialog.show();

        String date = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date());
        long timestamp = System.currentTimeMillis();

        final String finalComplaintType = complaintType;
        final String finalComplaintText = complaintText;
        final String finalDate = date;
        final long finalTimestamp = timestamp;

        if (fileUri != null) {
            StorageReference fileRef = storageReference.child(finalTimestamp + "_" + (consumerNumber != null ? consumerNumber : "guest"));
            fileRef.putFile(fileUri)
                    .addOnSuccessListener(taskSnapshot -> fileRef.getDownloadUrl().addOnSuccessListener(uri -> {
                        saveComplaintData(finalComplaintType, finalComplaintText, finalDate, finalTimestamp, uri.toString());
                    }))
                    .addOnFailureListener(e -> {
                        progressDialog.dismiss();
                        Toast.makeText(user_complaint.this, "File upload failed", Toast.LENGTH_SHORT).show();
                    });
        } else {
            saveComplaintData(finalComplaintType, finalComplaintText, finalDate, finalTimestamp, "");
        }
    }

    private void saveComplaintData(String complaintType, String complaintText, String date, long timestamp, String proofUrl) {
        Map<String, Object> complaint = new HashMap<>();
        complaint.put("consumerNumber", consumerNumber != null ? consumerNumber : "");
        complaint.put("username", username != null ? username : "Unknown");
        complaint.put("complaintType", complaintType);
        complaint.put("complaintText", complaintText);
        complaint.put("date", date);
        complaint.put("timestamp", timestamp);
        complaint.put("status", "Pending");
        complaint.put("proofUrl", proofUrl);
        complaint.put("adminReply", "No reply yet");

        db.collection("complaints")
                .add(complaint)
                .addOnSuccessListener(documentReference -> {
                    progressDialog.dismiss();
                    Toast.makeText(user_complaint.this, "Complaint submitted successfully", Toast.LENGTH_SHORT).show();
                    edtComplaint.setText("");
                    spinnerComplaintType.setSelection(0);
                    tvFileName.setText("No file selected");
                })
                .addOnFailureListener(e -> {
                    progressDialog.dismiss();
                    Toast.makeText(user_complaint.this, "Error submitting complaint", Toast.LENGTH_SHORT).show();
                });
    }

    private void listenLatestAdminReply() {
        if (consumerNumber == null || consumerNumber.isEmpty()) {
            return;
        }

        db.collection("complaints")
                .whereEqualTo("consumerNumber", consumerNumber)
                .orderBy("timestamp", Query.Direction.DESCENDING)
                .limit(1)
                .addSnapshotListener((QuerySnapshot snapshots, com.google.firebase.firestore.FirebaseFirestoreException e) -> {
                    if (e != null) return;
                    if (snapshots != null && !snapshots.isEmpty()) {
                        try {
                            String adminReply = snapshots.getDocuments().get(0).getString("adminReply");
                            if (adminReply == null || adminReply.isEmpty()) {
                                tvAdminReply.setText("No reply yet");
                            } else {
                                tvAdminReply.setText(adminReply);
                            }
                        } catch (Exception ex) {
                            tvAdminReply.setText("No reply yet");
                        }
                    } else {
                        tvAdminReply.setText("No reply yet");
                    }
                });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK) {
            if (requestCode == REQUEST_CODE_GALLERY && data != null) {
                fileUri = data.getData();
                if (fileUri != null) {
                    tvFileName.setText("Selected: " + fileUri.getLastPathSegment());
                }
            } else if (requestCode == REQUEST_CODE_CAMERA && data != null && data.getExtras() != null) {
                // Get image from camera as a bitmap
                android.graphics.Bitmap photo = (android.graphics.Bitmap) data.getExtras().get("data");
                // Save the image temporarily in MediaStore and get its URI
                String path = MediaStore.Images.Media.insertImage(getContentResolver(), photo, "camera_image", null);
                fileUri = Uri.parse(path);
                tvFileName.setText("Camera image selected");
            }
        }
    }
}


