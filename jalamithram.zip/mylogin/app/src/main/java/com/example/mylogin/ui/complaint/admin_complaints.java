//package com.example.mylogin.ui.complaint;
//
//
//import android.os.Bundle;
//import android.view.LayoutInflater;
//import android.view.View;
//import android.view.ViewGroup;
//import android.widget.Button;
//import android.widget.EditText;
//import android.widget.LinearLayout;
//import android.widget.TextView;
//import android.widget.Toast;
//
//import androidx.appcompat.app.AlertDialog;
//import androidx.fragment.app.Fragment;
//
//import com.google.firebase.firestore.FirebaseFirestore;
//import com.google.firebase.firestore.QueryDocumentSnapshot;
//
//public class admin_complaints extends Fragment {
//
//    private LinearLayout containerComplaints;
//    private FirebaseFirestore db;
//
//    public admin_complaints() {
//        // Required empty public constructor
//    }
//
//    @Override
//    public View onCreateView(LayoutInflater inflater, ViewGroup container,
//                             Bundle savedInstanceState) {
//        View root = inflater.inflate(R.layout.fragment_admin_complaints, container, false);
//
//        containerComplaints = root.findViewById(R.id.containerComplaints);
//        db = FirebaseFirestore.getInstance();
//
//        loadComplaints();
//
//        return root;
//    }
//
//    private void loadComplaints() {
//        db.collection("complaints")
//                .get()
//                .addOnSuccessListener(querySnapshot -> {
//                    containerComplaints.removeAllViews();
//                    LayoutInflater inflater = LayoutInflater.from(getContext());
//
//                    for (QueryDocumentSnapshot doc : querySnapshot) {
//                        View card = inflater.inflate(R.layout.item_admin_complaint, containerComplaints, false);
//
//                        TextView tvConsumer = card.findViewById(R.id.tvConsumerNumber);
//                        TextView tvUsername = card.findViewById(R.id.tvUsername);
//                        TextView tvType = card.findViewById(R.id.tvComplaintType);
//                        TextView tvText = card.findViewById(R.id.tvComplaintText);
//                        TextView tvDate = card.findViewById(R.id.tvDate);
//                        TextView tvReply = card.findViewById(R.id.tvAdminReply);
//                        Button btnReply = card.findViewById(R.id.btnReply);
//
//                        String docId = doc.getId();
//
//                        tvConsumer.setText("Consumer: " + doc.getString("consumerNumber"));
//                        tvUsername.setText("Username: " + doc.getString("username"));
//                        tvType.setText("Type: " + doc.getString("complaintType"));
//                        tvText.setText("Complaint: " + doc.getString("complaintText"));
//                        tvDate.setText("Date: " + doc.getString("date"));
//                        tvReply.setText("Reply: " + doc.getString("adminReply"));
//
//                        btnReply.setOnClickListener(v -> showReplyDialog(docId, doc.getString("adminReply")));
//
//                        containerComplaints.addView(card);
//                    }
//                })
//                .addOnFailureListener(e ->
//                        Toast.makeText(getContext(), "Error loading complaints", Toast.LENGTH_SHORT).show());
//    }
//
//    private void showReplyDialog(final String docId, String oldReply) {
//        AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
//        builder.setTitle("Reply to Complaint");
//
//        View dialogView = getLayoutInflater().inflate(R.layout.dialog_admin_reply, null);
//        final EditText edtReply = dialogView.findViewById(R.id.edtAdminReply);
//        edtReply.setText(oldReply != null ? oldReply : "");
//
//        builder.setView(dialogView);
//        builder.setPositiveButton("Submit", (dialog, which) -> {
//            String reply = edtReply.getText().toString().trim();
//            if (!reply.isEmpty()) {
//                db.collection("complaints").document(docId)
//                        .update("adminReply", reply, "status", "Replied")
//                        .addOnSuccessListener(aVoid ->
//                                Toast.makeText(getContext(), "Reply sent successfully", Toast.LENGTH_SHORT).show())
//                        .addOnFailureListener(e ->
//                                Toast.makeText(getContext(), "Failed to send reply", Toast.LENGTH_SHORT).show());
//            }
//        });
//
//        builder.setNegativeButton("Cancel", null);
//        builder.show();
//    }
//}
