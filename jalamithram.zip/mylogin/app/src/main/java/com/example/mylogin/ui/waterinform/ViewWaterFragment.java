package com.example.mylogin.ui.waterinform;





import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.mylogin.R;
import com.example.mylogin.ui.waterinform.waterinfo;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;

public class ViewWaterFragment extends Fragment {

    private RecyclerView recyclerView;
    private ProgressBar progressBar;
    private FirebaseFirestore db;
    private ArrayList<waterinfo> waterList;
    private WaterAdapter adapter;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        // Inflate the correct layout (make sure the XML file name matches)
        View root = inflater.inflate(R.layout.fragment_view_water, container, false);

        // find views (IDs must match your fragment_view_water.xml)
        recyclerView = root.findViewById(R.id.recyclerViewSchedules);
        progressBar = root.findViewById(R.id.progressBar);

        // RecyclerView setup
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(requireContext()));

        // Firestore + data + adapter
        db = FirebaseFirestore.getInstance();
        waterList = new ArrayList<>();
        adapter = new WaterAdapter(waterList);
        recyclerView.setAdapter(adapter);

        // Load data
        loadWaterSchedules();

        return root;
    }

    private void loadWaterSchedules() {
        // show loading
        if (progressBar != null) progressBar.setVisibility(View.VISIBLE);

        db.collection("waterSchedules")
                .get()
                .addOnCompleteListener(task -> {
                    // hide loading
                    if (progressBar != null) progressBar.setVisibility(View.GONE);

                    if (task.isSuccessful() && task.getResult() != null) {
                        waterList.clear();
                        for (QueryDocumentSnapshot doc : task.getResult()) {
                            // convert to model and set id (ensure waterinfo has a no-arg constructor)
                            waterinfo info = doc.toObject(waterinfo.class);
                            if (info != null) {
                                info.setId(doc.getId());
                                waterList.add(info);
                            }
                        }
                        adapter.notifyDataSetChanged();
                    } else {
                        Toast.makeText(requireContext(), "Failed to load data", Toast.LENGTH_SHORT).show();
                    }
                })
                .addOnFailureListener(e -> {
                    if (progressBar != null) progressBar.setVisibility(View.GONE);
                    Toast.makeText(requireContext(), "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
    }
}
