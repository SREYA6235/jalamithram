package com.example.mylogin.ui.payment;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.mylogin.R;

import java.util.Random;

public class userpaymentFragment extends Fragment {

    private static final int CAMERA_REQUEST_CODE = 100;

    private Button buttonCaptureMeterImage, buttonPay;
    private ImageView imageMeter;
    private TextView textMeterReading, textBillAmount, textPaymentStatus;

    private Bitmap meterImage;
    private int meterReading = 0;
    private double billAmount = 0.0;

    public userpaymentFragment() {
        // Required empty constructor
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.activity_userpayment, container, false);

        // Initialize views
        buttonCaptureMeterImage = view.findViewById(R.id.buttonUploadMeterImage);
        buttonPay = view.findViewById(R.id.buttonPay);
        imageMeter = view.findViewById(R.id.imageMeter);
        textMeterReading = view.findViewById(R.id.textMeterReading);
        textBillAmount = view.findViewById(R.id.textBillAmount);
        textPaymentStatus = view.findViewById(R.id.textPaymentStatus);

        // Capture meter image via camera
        buttonCaptureMeterImage.setOnClickListener(v -> openCamera());

        // Pay button click
        buttonPay.setOnClickListener(v -> {
            if (billAmount > 0) {
                textPaymentStatus.setText("Status: Paid");
                Toast.makeText(getActivity(), "Payment Successful! ₹" + billAmount, Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(getActivity(), "Please capture meter image first.", Toast.LENGTH_SHORT).show();
            }
        });

        return view;
    }

    // Open camera
    private void openCamera() {
        Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (cameraIntent.resolveActivity(getActivity().getPackageManager()) != null) {
            startActivityForResult(cameraIntent, CAMERA_REQUEST_CODE);
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == CAMERA_REQUEST_CODE && resultCode == Activity.RESULT_OK && data != null) {
            meterImage = (Bitmap) data.getExtras().get("data");
            if (meterImage != null) {
                imageMeter.setImageBitmap(meterImage);

                // 🔹 Simulate extracting meter reading from image (dummy random value for now)
                meterReading = new Random().nextInt(500) + 50; // random between 50–550
                textMeterReading.setText("Meter Reading: " + meterReading);

                // Calculate bill based on reading
                calculateBill();

                Toast.makeText(getActivity(), "Meter image processed. Bill generated.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    // Calculate bill amount
    private void calculateBill() {
        billAmount = meterReading * 5.0; // Example: ₹5 per unit
        textBillAmount.setText("Bill Amount: ₹" + String.format("%.2f", billAmount));
        textPaymentStatus.setText("Status: Pending");
    }
}
