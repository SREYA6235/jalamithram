package com.example.mylogin;

public class UserSession {
    public static String consumerNumber = "";
    public static String phoneNumber = "";
    public static String username = "";

    public static boolean isLoggedIn() {
        return consumerNumber != null && !consumerNumber.isEmpty()
                && phoneNumber != null && !phoneNumber.isEmpty();
    }

    public static void clear() {
        consumerNumber = "";
        phoneNumber = "";
        username = "";
    }
}
