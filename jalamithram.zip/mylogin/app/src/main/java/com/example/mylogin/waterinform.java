package com.example.mylogin;

public class waterinform {
    private String id;
    private String area;
    private String date;
    private String arrivalTime;
    private String closingTime;

    public waterinform() {
        // Empty constructor required for Firestore
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getArea() { return area; }
    public void setArea(String area) { this.area = area; }

    public String getDate() { return date; }
    public void setDate(String date) { this.date = date; }

    public String getArrivalTime() { return arrivalTime; }
    public void setArrivalTime(String arrivalTime) { this.arrivalTime = arrivalTime; }

    public String getClosingTime() { return closingTime; }
    public void setClosingTime(String closingTime) { this.closingTime = closingTime; }
}
