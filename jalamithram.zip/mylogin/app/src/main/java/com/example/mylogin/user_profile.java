package com.example.mylogin;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

public class user_profile extends AppCompatActivity {

    private TextView tvConsumerNumber, tvUsername, tvContact, tvAddress, tvArea, tvCardType, tvPaymentStatus;
    private Button btnLogout;
    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_profile);

        tvConsumerNumber = findViewById(R.id.tvConsumerNumber);
        tvUsername = findViewById(R.id.tvUsername);
        tvContact = findViewById(R.id.tvContact);
        tvAddress = findViewById(R.id.tvAddress);
        tvArea = findViewById(R.id.tvArea);
        tvCardType = findViewById(R.id.tvCardType);
        tvPaymentStatus = findViewById(R.id.tvPaymentStatus);
        btnLogout = findViewById(R.id.btnLogout);

        db = FirebaseFirestore.getInstance();

        // Get the consumer number from login page
        String consumerNumber = getIntent().getStringExtra("consumerNumber");
        if (consumerNumber != null) {
            loadUserProfile(consumerNumber);
        } else {
            Toast.makeText(this, "No user data found!", Toast.LENGTH_SHORT).show();
        }

        btnLogout.setOnClickListener(v -> {
            Intent intent = new Intent(user_profile.this, userlogin.class);
            startActivity(intent);
            finish();
        });
    }

    private void loadUserProfile(String consumerNumber) {
        db.collection("UserProfiles")
                .document(consumerNumber)
                .get()
                .addOnSuccessListener(documentSnapshot -> {
                    if (documentSnapshot.exists()) {
                        tvConsumerNumber.setText("Consumer Number: " + documentSnapshot.getString("consumerNumber"));
                        tvUsername.setText("Username: " + documentSnapshot.getString("username"));
                        tvContact.setText("Contact: " + documentSnapshot.getString("contact"));
                        tvAddress.setText("Address: " + documentSnapshot.getString("address"));
                        tvArea.setText("Area: " + documentSnapshot.getString("area"));
                        tvCardType.setText("Card Type: " + documentSnapshot.getString("cardType"));
                        tvPaymentStatus.setText("Payment Status: " + documentSnapshot.getString("paymentStatus"));
                    } else {
                        Toast.makeText(this, "User not found!", Toast.LENGTH_SHORT).show();
                    }
                })
                .addOnFailureListener(e ->
                        Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show()
                );
    }
}
