package com.example.mylogin;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.mylogin.ui.waterinform.ViewWaterFragment;

public class MainActivity2 extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);  // 🔄 Moved to the top
        setContentView(R.layout.activity_main2);
        TextView wa=(TextView)  findViewById(R.id.wat);
        Button adm = (Button) findViewById(R.id.button3);
        Button us = (Button) findViewById(R.id.button4);
//        Button pub=(Button) findViewById(R.id.bv);


        adm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity2.this,alogin.class);
                startActivity(intent);
            }
        });

        us.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity2.this, userlogin.class);
                startActivity(intent);
            }
        });
//        pub.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent intent = new Intent(MainActivity2.this,userviewwaterinform.class);
//                startActivity(intent);
//            }
//        });
//        // ✅ When clicking "water information updates! click me"
//        wa.setOnClickListener(v -> {
//            Intent intent = new Intent(MainActivity2.this,viewfragment.class);
//            startActivity(intent);
//        });
        TextView createAccount = findViewById(R.id.wat);
        createAccount.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity2.this, userviewwaterinform.class);
            startActivity(intent);
        });



    }
}
