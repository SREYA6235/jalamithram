package com.example.mylogin.ui.waterinform;


public class waterinfo {
    private String id; // <-- Add this
    private String area;
    private String date;
    private String arrivalTime;
    private String closingTime;

    // Empty constructor required for Firestore
    public waterinfo() {}

    // Full constructor
    public waterinfo(String area, String date, String arrivalTime, String closingTime) {
        this.area = area;
        this.date = date;
        this.arrivalTime = arrivalTime;
        this.closingTime = closingTime;
    }

    // Getter and Setter for id
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    // Other getters
    public String getArea() {
        return area;
    }

    public String getDate() {
        return date;
    }

    public String getArrivalTime() {
        return arrivalTime;
    }

    public String getClosingTime() {
        return closingTime;
    }

    // Optional: Setters for other fields if you want to update them
    public void setArea(String area) { this.area = area; }
    public void setDate(String date) { this.date = date; }
    public void setArrivalTime(String arrivalTime) { this.arrivalTime = arrivalTime; }
    public void setClosingTime(String closingTime) { this.closingTime = closingTime; }
}


