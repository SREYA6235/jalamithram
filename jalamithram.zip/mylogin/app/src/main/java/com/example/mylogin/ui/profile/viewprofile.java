package com.example.mylogin.ui.profile;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.mylogin.R;
import com.example.mylogin.ui.complaint.admin_complaint_view;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

public class viewprofile extends Fragment {

    private TextView tvUsername, tvContact, tvConsumerNumber, tvAddress, tvCardType, tvCurrentBill;
    private Button btnViewComplaints, btnViewPayments, btnViewStatus, btnSendReminder;
    private LinearLayout adminControls;

    private FirebaseFirestore db;
    private FirebaseAuth auth;

    private String consumerNumber; // passed from login or previous page
    private boolean isAdmin = false; // dynamically set

    public viewprofile() { }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_viewprofile, container, false);

        // Initialize UI components
        tvUsername = view.findViewById(R.id.tvUsername);
        tvContact = view.findViewById(R.id.tvContact);
        tvConsumerNumber = view.findViewById(R.id.tvConsumerNumber);
        tvAddress = view.findViewById(R.id.tvAddress);
        tvCardType = view.findViewById(R.id.tvCardType);
        tvCurrentBill = view.findViewById(R.id.tvStatus);

        adminControls = view.findViewById(R.id.adminControls);

        btnViewComplaints = view.findViewById(R.id.btnViewComplaints);
        btnViewPayments = view.findViewById(R.id.btnViewPayments);
        btnViewStatus = view.findViewById(R.id.btnViewStatus);
        btnSendReminder = view.findViewById(R.id.btnSendReminder);

        // Initialize Firebase
        db = FirebaseFirestore.getInstance();
        auth = FirebaseAuth.getInstance();

        // Retrieve data passed from login or admin dashboard
        if (getArguments() != null) {
            consumerNumber = getArguments().getString("consumerNumber");
            isAdmin = getArguments().getBoolean("isAdmin", false);
        }

        // Show admin buttons only if the logged-in user is admin
        if (isAdmin) {
            adminControls.setVisibility(View.VISIBLE);
        } else {
            adminControls.setVisibility(View.GONE);
        }

        // Load the user data
        loadUserProfile();

        // Example navigation button listeners (you can replace with real fragment calls)
//        btnViewComplaints.setOnClickListener(v ->
//                Toast.makeText(getContext(), "View Complaints clicked", Toast.LENGTH_SHORT).show()
//        );


        btnViewComplaints.setOnClickListener(v -> {
            Intent intent = new Intent(getActivity(), admin_complaint_view.class);
            startActivity(intent);
        });


        btnViewPayments.setOnClickListener(v ->
                Toast.makeText(getContext(), "View Payments clicked", Toast.LENGTH_SHORT).show()
        );

        btnViewStatus.setOnClickListener(v ->
                Toast.makeText(getContext(), "View Status clicked", Toast.LENGTH_SHORT).show()
        );

        btnSendReminder.setOnClickListener(v -> sendReminder());

        return view;
    }

    private void loadUserProfile() {
        if (consumerNumber == null || consumerNumber.isEmpty()) {
            Toast.makeText(getContext(), "Invalid Consumer Number", Toast.LENGTH_SHORT).show();
            return;
        }

        // Reference to document based on consumerNumber
        DocumentReference docRef = db.collection("UserProfiles").document(consumerNumber);
        docRef.get()
                .addOnSuccessListener(documentSnapshot -> {
                    if (documentSnapshot.exists()) {
                        tvUsername.setText("Username: " + documentSnapshot.getString("username"));
                        tvContact.setText("Contact: " + documentSnapshot.getString("contact"));
                        tvConsumerNumber.setText("Consumer Number: " + documentSnapshot.getString("consumerNumber"));
                        tvAddress.setText("Address: " + documentSnapshot.getString("address"));
                        tvCardType.setText("Card Type: " + documentSnapshot.getString("cardType"));
                        tvCurrentBill.setText("Current Bill: ₹" + documentSnapshot.getString("currentBill"));

                    } else {
                        Toast.makeText(getContext(), "Profile not found.", Toast.LENGTH_SHORT).show();
                    }
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(getContext(), "Failed to load profile: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
    }

    private void sendReminder() {
        // Example: Just show a Toast (you can later replace this with Firebase Cloud Messaging)
        Toast.makeText(getContext(), "Reminder sent to user successfully!", Toast.LENGTH_SHORT).show();
    }
}


