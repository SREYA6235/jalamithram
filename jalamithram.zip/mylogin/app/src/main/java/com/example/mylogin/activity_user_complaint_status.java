package com.example.mylogin;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.mylogin.R;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

public class activity_user_complaint_status extends AppCompatActivity {

    private LinearLayout containerUserComplaints;
    private FirebaseFirestore db;
    private String consumerNumber;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_complaint_status);

        containerUserComplaints = (LinearLayout) findViewById(R.id.containerUserComplaints);
        db = FirebaseFirestore.getInstance();

        // get consumerNumber from Intent
        consumerNumber = getIntent().getStringExtra("consumerNumber");
        if (consumerNumber == null || consumerNumber.isEmpty()) {
            Toast.makeText(this, "No consumer number provided", Toast.LENGTH_SHORT).show();
            return;
        }

        loadUserComplaints();
    }

    private void loadUserComplaints() {
        db.collection("complaints")
                .whereEqualTo("consumerNumber", consumerNumber)
                .get()
                .addOnSuccessListener(querySnapshot -> {
                    containerUserComplaints.removeAllViews();
                    LayoutInflater inflater = LayoutInflater.from(activity_user_complaint_status.this);

                    if (querySnapshot.isEmpty()) {
                        Toast.makeText(activity_user_complaint_status.this, "No complaints found", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    for (QueryDocumentSnapshot doc : querySnapshot) {
                        View card = inflater.inflate(R.layout.item_user_complaint_status, containerUserComplaints, false);

                        // explicit casts to avoid "incompatible types" errors
                        TextView tvType = (TextView) card.findViewById(R.id.tvComplaintType);
                        TextView tvText = (TextView) card.findViewById(R.id.tvComplaintText);
                        TextView tvDate = (TextView) card.findViewById(R.id.tvDate);
                        TextView tvStatus = (TextView) card.findViewById(R.id.tvStatus);
                        TextView tvAdminReply = (TextView) card.findViewById(R.id.tvAdminReply);

                        // safe-get with defaults
                        String type = doc.getString("complaintType");
                        String text = doc.getString("complaintText");
                        String date = doc.getString("date");
                        String status = doc.getString("status");
                        String reply = doc.getString("adminReply");

                        tvType.setText("Type: " + (type != null ? type : "N/A"));
                        tvText.setText("Complaint: " + (text != null ? text : "N/A"));
                        tvDate.setText("Date: " + (date != null ? date : "N/A"));
                        tvStatus.setText("Status: " + (status != null ? status : "Pending"));
                        tvAdminReply.setText("Reply: " + (reply != null ? reply : "No reply yet"));

                        containerUserComplaints.addView(card);
                    }
                })
                .addOnFailureListener(e ->
                        Toast.makeText(activity_user_complaint_status.this, "Failed to load complaints: " + e.getMessage(), Toast.LENGTH_SHORT).show());
    }
}

