package com.example.mylogin.ui.waterinform;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;

import com.example.mylogin.R;
import com.example.mylogin.updatewatershedule;
import com.example.mylogin.item_schedule;
import com.example.mylogin.updatewatershedule;
import com.example.mylogin.userviewwaterinform;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

public class waterinfoFragment extends Fragment {

    private EditText editTextArea, editTextDate, editTextArrivalTime, editTextClosingTime;
    private Button buttonAdd;
    private LinearLayout layoutScheduleContainer;
    private Context context;
    private Calendar calendar;
    private ArrayList<waterinfo> waterInfoList;
    private FirebaseFirestore db;

    private ActivityResultLauncher<Intent> updateLauncher;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_waterinfo, container, false);

        context = getContext();
        db = FirebaseFirestore.getInstance();

        // Bind Views
        editTextArea = root.findViewById(R.id.editTextArea);
        editTextDate = root.findViewById(R.id.editTextDate);
        editTextArrivalTime = root.findViewById(R.id.editTextArrivalTime);
        editTextClosingTime = root.findViewById(R.id.editTextClosingTime);
        buttonAdd = root.findViewById(R.id.buttonAdd);
        Button buttonViewAll = root.findViewById(R.id.ww);

        buttonViewAll.setOnClickListener(v -> {
            Intent intent = new Intent(getActivity(), userviewwaterinform.class);
            startActivity(intent);
        });

        layoutScheduleContainer = root.findViewById(R.id.layoutScheduleItem);


        calendar = Calendar.getInstance();
        waterInfoList = new ArrayList<>();

        // Register ActivityResultLauncher for Update
        updateLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == getActivity().RESULT_OK) {
                        // Reload all schedules after returning from Update activity
                        loadSchedulesFromFirebase();
                    }
                }
        );

        // Load schedules from Firebase
        loadSchedulesFromFirebase();

        // Date Picker
        editTextDate.setOnClickListener(v -> {
            DatePickerDialog datePickerDialog = new DatePickerDialog(context,
                    (view, year, month, dayOfMonth) ->
                            editTextDate.setText(dayOfMonth + "/" + (month + 1) + "/" + year),
                    calendar.get(Calendar.YEAR),
                    calendar.get(Calendar.MONTH),
                    calendar.get(Calendar.DAY_OF_MONTH));
            datePickerDialog.show();
        });

        // Time Pickers
        editTextArrivalTime.setOnClickListener(v -> showTimePicker(editTextArrivalTime));
        editTextClosingTime.setOnClickListener(v -> showTimePicker(editTextClosingTime));

        // Add Button
        buttonAdd.setOnClickListener(v -> addScheduleToFirebase());

        return root;
    }

    private void showTimePicker(EditText editText) {
        TimePickerDialog timePickerDialog = new TimePickerDialog(context,
                (view, hourOfDay, minute) ->
                        editText.setText(String.format("%02d:%02d", hourOfDay, minute)),
                12, 0, true);
        timePickerDialog.show();
    }

    private void clearFields() {
        editTextArea.setText("");
        editTextDate.setText("");
        editTextArrivalTime.setText("");
        editTextClosingTime.setText("");
    }

    private void loadSchedulesFromFirebase() {
        db.collection("waterSchedules")
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful() && task.getResult() != null) {
                        layoutScheduleContainer.removeAllViews();
                        waterInfoList.clear();
                        for (QueryDocumentSnapshot doc : task.getResult()) {
                            waterinfo info = doc.toObject(waterinfo.class);
                            info.setId(doc.getId());
                            waterInfoList.add(info);
                            addScheduleView(info);
                        }
                    } else {
                        Toast.makeText(context, "Failed to load schedules", Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void addScheduleToFirebase() {
        String area = editTextArea.getText().toString().trim();
        String date = editTextDate.getText().toString().trim();
        String arrival = editTextArrivalTime.getText().toString().trim();
        String closing = editTextClosingTime.getText().toString().trim();

        if (area.isEmpty() || date.isEmpty() || arrival.isEmpty() || closing.isEmpty()) {
            Toast.makeText(context, "Fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        Map<String, Object> schedule = new HashMap<>();
        schedule.put("area", area);
        schedule.put("date", date);
        schedule.put("arrivalTime", arrival);
        schedule.put("closingTime", closing);

        db.collection("waterSchedules")
                .add(schedule)
                .addOnSuccessListener(documentReference -> {
                    waterinfo info = new waterinfo(area, date, arrival, closing);
                    info.setId(documentReference.getId());
                    waterInfoList.add(info);
                    addScheduleView(info);
                    clearFields();
                    Toast.makeText(context, "Schedule Added", Toast.LENGTH_SHORT).show();
                })
                .addOnFailureListener(e ->
                        Toast.makeText(context, "Failed to add schedule", Toast.LENGTH_SHORT).show());
    }

    private void addScheduleView(waterinfo info) {
        LinearLayout scheduleView = new LinearLayout(context);
        scheduleView.setOrientation(LinearLayout.VERTICAL);
        scheduleView.setPadding(12, 12, 12, 12);
        scheduleView.setBackgroundColor(getResources().getColor(android.R.color.white));

        TextView textViewArea = new TextView(context);
        textViewArea.setText("Area: " + info.getArea());
        textViewArea.setTextSize(16f);
        textViewArea.setTextColor(getResources().getColor(android.R.color.black));

        TextView textViewDate = new TextView(context);
        textViewDate.setText("Date: " + info.getDate());
        textViewDate.setTextColor(getResources().getColor(android.R.color.darker_gray));

        TextView textViewArrival = new TextView(context);
        textViewArrival.setText("Arrival: " + info.getArrivalTime());
        textViewArrival.setTextColor(getResources().getColor(android.R.color.darker_gray));

        TextView textViewClosing = new TextView(context);
        textViewClosing.setText("Closing: " + info.getClosingTime());
        textViewClosing.setTextColor(getResources().getColor(android.R.color.darker_gray));

        LinearLayout buttonLayout = new LinearLayout(context);
        buttonLayout.setOrientation(LinearLayout.HORIZONTAL);
        buttonLayout.setGravity(android.view.Gravity.END);

        Button buttonView = new Button(context);
        buttonView.setText("View");
        buttonView.setBackgroundTintList(getResources().getColorStateList(android.R.color.holo_blue_light));
        buttonView.setTextColor(getResources().getColor(android.R.color.white));

        Button buttonUpdate = new Button(context);
        buttonUpdate.setText("Update");
        buttonUpdate.setBackgroundTintList(getResources().getColorStateList(android.R.color.holo_orange_light));
        buttonUpdate.setTextColor(getResources().getColor(android.R.color.white));

        Button buttonDelete = new Button(context);
        buttonDelete.setText("Delete");
        buttonDelete.setBackgroundTintList(getResources().getColorStateList(android.R.color.holo_red_light));
        buttonDelete.setTextColor(getResources().getColor(android.R.color.white));

        buttonLayout.addView(buttonView);
        buttonLayout.addView(buttonUpdate);
        buttonLayout.addView(buttonDelete);

        scheduleView.addView(textViewArea);
        scheduleView.addView(textViewDate);
        scheduleView.addView(textViewArrival);
        scheduleView.addView(textViewClosing);
        scheduleView.addView(buttonLayout);

        // View schedule
        buttonView.setOnClickListener(v -> {
            Intent intent = new Intent(context, item_schedule.class);
            intent.putExtra("area", info.getArea());
            intent.putExtra("date", info.getDate());
            intent.putExtra("arrival", info.getArrivalTime());
            intent.putExtra("closing", info.getClosingTime());
            startActivity(intent);
        });

        // Update schedule
        buttonUpdate.setOnClickListener(v -> {
            Intent intent = new Intent(context, updatewatershedule.class);
            intent.putExtra("id", info.getId());
            intent.putExtra("area", info.getArea());
            intent.putExtra("date", info.getDate());
            intent.putExtra("arrival", info.getArrivalTime());
            intent.putExtra("closing", info.getClosingTime());
            updateLauncher.launch(intent);
        });

        // Delete schedule
        // Delete schedule
        buttonDelete.setOnClickListener(v -> {
            new AlertDialog.Builder(context)
                    .setTitle("Confirm Delete")
                    .setMessage("Are you sure you want to delete this schedule?")
                    .setIcon(android.R.drawable.ic_dialog_alert)
                    .setPositiveButton("Yes", (dialog, which) -> {
                        db.collection("waterSchedules").document(info.getId())
                                .delete()
                                .addOnSuccessListener(aVoid -> {
                                    waterInfoList.remove(info);
                                    layoutScheduleContainer.removeView(scheduleView);
                                    Toast.makeText(context, "Deleted successfully", Toast.LENGTH_SHORT).show();
                                })
                                .addOnFailureListener(e ->
                                        Toast.makeText(context, "Delete failed", Toast.LENGTH_SHORT).show()
                                );
                    })
                    .setNegativeButton("No", (dialog, which) -> dialog.dismiss())
                    .create()
                    .show();
        });


        layoutScheduleContainer.addView(scheduleView);
    }
}
