package com.example.mylogin.ui.profile;

import android.app.AlertDialog;
import android.os.Bundle;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.mylogin.R;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.HashMap;
import java.util.Map;

public class fragment_view_all_users extends Fragment {

    private LinearLayout containerUsers;
    private FirebaseFirestore db;

    public fragment_view_all_users () { }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_view_all_users, container, false);
        containerUsers = view.findViewById(R.id.containerUsers);
        db = FirebaseFirestore.getInstance();

        loadAllUsers();
        return view;
    }

    private void loadAllUsers() {
        db.collection("UserProfiles")
                .get()
                .addOnSuccessListener(querySnapshot -> {
                    containerUsers.removeAllViews();

                    if (querySnapshot.isEmpty()) {
                        Toast.makeText(getContext(), "No user profiles found!", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    for (QueryDocumentSnapshot doc : querySnapshot) {
                        String username = doc.getString("username");
                        String contact = doc.getString("contact");
                        String consumerNumber = doc.getString("consumerNumber");
                        String address = doc.getString("address");
                        String cardType = doc.getString("cardType");
                        String currentBill = doc.getString("currentBill");
                        String paymentStatus = doc.getString("paymentStatus");

                        // Create user card dynamically
                        View userCard = createUserCard(username, contact, consumerNumber, address, cardType, currentBill, paymentStatus);
                        containerUsers.addView(userCard);
                    }
                })
                .addOnFailureListener(e ->
                        Toast.makeText(getContext(), "Failed to load users: " + e.getMessage(), Toast.LENGTH_SHORT).show()
                );
    }

    private View createUserCard(String username, String contact, String consumerNumber,
                                String address, String cardType, String currentBill, String paymentStatus) {

        LinearLayout card = new LinearLayout(getContext());
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackgroundResource(R.drawable.card_background);
        card.setPadding(30, 25, 30, 25);
        card.setElevation(8f);

        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        params.setMargins(0, 20, 0, 0);
        card.setLayoutParams(params);

        // Create TextViews
        TextView tvInfo = new TextView(getContext());
        tvInfo.setText("👤 " + username +
                "\n📞 " + contact +
                "\n🏠 " + address +
                "\n💳 " + cardType +
                "\n🔢 Consumer: " + consumerNumber +
                "\n💰 Current Bill: ₹" + currentBill +
                "\n💸 Payment Status: " + (paymentStatus == null ? "Pending" : paymentStatus));
        tvInfo.setTextSize(16f);
        tvInfo.setTextColor(0xFF0B5394);
        tvInfo.setPadding(0, 0, 0, 15);

        // Create buttons
        LinearLayout btnLayout = new LinearLayout(getContext());
        btnLayout.setOrientation(LinearLayout.HORIZONTAL);

        Button btnDelete = new Button(getContext());
        btnDelete.setText("Delete");
        btnDelete.setBackgroundTintList(getResources().getColorStateList(android.R.color.holo_red_dark, null));
        btnDelete.setTextColor(getResources().getColor(android.R.color.white));

        Button btnUpdate = new Button(getContext());
        btnUpdate.setText("Update");
        btnUpdate.setBackgroundTintList(getResources().getColorStateList(android.R.color.holo_blue_dark, null));
        btnUpdate.setTextColor(getResources().getColor(android.R.color.white));
        btnUpdate.setLayoutParams(new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1
        ));

        btnLayout.addView(btnUpdate);
        btnLayout.addView(btnDelete);

        // Add views to card
        card.addView(tvInfo);
        card.addView(btnLayout);

        // Button listeners
        btnDelete.setOnClickListener(v -> deleteUser(consumerNumber, card));
        btnUpdate.setOnClickListener(v -> updateUserInfo(consumerNumber));

        return card;
    }

    private void deleteUser(String consumerNumber, View cardView) {
        new AlertDialog.Builder(getContext())
                .setTitle("Delete User")
                .setMessage("Are you sure you want to delete this user?")
                .setPositiveButton("Yes", (dialog, which) -> {
                    db.collection("UserProfiles").document(consumerNumber)
                            .delete()
                            .addOnSuccessListener(aVoid -> {
                                Toast.makeText(getContext(), "✅ User deleted successfully!", Toast.LENGTH_SHORT).show();
                                containerUsers.removeView(cardView);
                            })
                            .addOnFailureListener(e ->
                                    Toast.makeText(getContext(), "❌ Failed to delete user: " + e.getMessage(), Toast.LENGTH_SHORT).show()
                            );
                })
                .setNegativeButton("No", null)
                .show();
    }

    private void updateUserInfo(String consumerNumber) {
        // Dialog to update payment status
        EditText input = new EditText(getContext());
        input.setHint("Enter Payment Status (Paid / Pending)");
        input.setInputType(InputType.TYPE_CLASS_TEXT);

        new AlertDialog.Builder(getContext())
                .setTitle("Update Payment Status")
                .setView(input)
                .setPositiveButton("Update", (dialog, which) -> {
                    String status = input.getText().toString().trim();
                    if (status.isEmpty()) {
                        Toast.makeText(getContext(), "Enter a valid status!", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    Map<String, Object> update = new HashMap<>();
                    update.put("paymentStatus", status);

                    db.collection("UserProfiles").document(consumerNumber)
                            .update(update)
                            .addOnSuccessListener(aVoid -> {
                                Toast.makeText(getContext(), "✅ Payment status updated!", Toast.LENGTH_SHORT).show();
                                loadAllUsers(); // refresh list
                            })
                            .addOnFailureListener(e ->
                                    Toast.makeText(getContext(), "❌ Failed to update: " + e.getMessage(), Toast.LENGTH_SHORT).show()
                            );
                })
                .setNegativeButton("Cancel", null)
                .show();
    }
}
