package com.example.mylogin;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.example.mylogin.R;

import java.util.HashMap;
import java.util.Map;

public class ViewAllUsersActivity extends AppCompatActivity {

    private LinearLayout containerUsers;
    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_all_users);

        containerUsers = findViewById(R.id.containerUsers);
        db = FirebaseFirestore.getInstance();

        loadAllUsers();
    }

    private void loadAllUsers() {
        db.collection("UserProfiles")
                .get()
                .addOnSuccessListener(querySnapshot -> {
                    containerUsers.removeAllViews();

                    if (querySnapshot.isEmpty()) {
                        Toast.makeText(this, "No user profiles found!", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    for (QueryDocumentSnapshot doc : querySnapshot) {
                        String username = doc.getString("username");
                        String contact = doc.getString("contact");
                        String consumerNumber = doc.getString("consumerNumber");
                        String address = doc.getString("address");
                        String cardType = doc.getString("cardType");
                        String currentBill = doc.getString("currentBill");
                        String paymentStatus = doc.getString("paymentStatus");

                        View userCard = createUserCard(username, contact, consumerNumber, address, cardType, currentBill, paymentStatus);
                        containerUsers.addView(userCard);
                    }
                })
                .addOnFailureListener(e ->
                        Toast.makeText(this, "Failed to load users: " + e.getMessage(), Toast.LENGTH_SHORT).show()
                );
    }

    private View createUserCard(String username, String contact, String consumerNumber,
                                String address, String cardType, String currentBill, String paymentStatus) {

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackgroundResource(R.drawable.card_background);
        card.setPadding(30, 25, 30, 25);
        card.setElevation(8f);

        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        params.setMargins(0, 20, 0, 0);
        card.setLayoutParams(params);

        // User info
        TextView tvInfo = new TextView(this);
        tvInfo.setText("👤 Name: " + username +
                "\n📞 Contact: " + contact +
                "\n🏠 Address: " + address +
                "\n💳 Card Type: " + cardType +
                "\n🔢 Consumer No: " + consumerNumber +
                "\n💰 Current Bill: ₹" + currentBill);
        tvInfo.setTextSize(16f);
        tvInfo.setTextColor(0xFF0B5394);
        tvInfo.setPadding(0, 0, 0, 10);

        // Bill status
        TextView tvStatus = new TextView(this);
        tvStatus.setText("Bill Status: " + (paymentStatus == null ? "Pending" : paymentStatus));
        tvStatus.setTextSize(16f);
        tvStatus.setTextColor(paymentStatus != null && paymentStatus.equalsIgnoreCase("Paid")
                ? 0xFF1B5E20 // Green
                : 0xFFD32F2F // Red
        );
        tvStatus.setPadding(0, 0, 0, 20);

        // Buttons: Update + Delete
        LinearLayout btnTopLayout = new LinearLayout(this);
        btnTopLayout.setOrientation(LinearLayout.HORIZONTAL);
        btnTopLayout.setGravity(Gravity.CENTER);

        Button btnUpdate = createStyledButton("Update", android.R.color.holo_blue_dark);
        Button btnDelete = createStyledButton("Delete", android.R.color.holo_red_dark);

        btnUpdate.setOnClickListener(v -> updateUserInfo(consumerNumber));
        btnDelete.setOnClickListener(v -> deleteUser(consumerNumber, card));

        btnTopLayout.addView(btnUpdate);
        btnTopLayout.addView(btnDelete);

        // Extra feature buttons
        LinearLayout btnFeatureLayout = new LinearLayout(this);
        btnFeatureLayout.setOrientation(LinearLayout.HORIZONTAL);
        btnFeatureLayout.setGravity(Gravity.CENTER);

        Button btnViewComplaints = createStyledButton("View Complaints", android.R.color.holo_orange_dark);
        Button btnSendReminder = createStyledButton("Send Reminder", android.R.color.holo_purple);
        Button btnViewPayment = createStyledButton("View Payment", android.R.color.holo_green_dark);

        btnViewComplaints.setOnClickListener(v ->
                Toast.makeText(this, "Opening complaints for " + username, Toast.LENGTH_SHORT).show());

        btnSendReminder.setOnClickListener(v ->
                sendPaymentReminder(username, contact, consumerNumber, paymentStatus));

        btnViewPayment.setOnClickListener(v ->
                Toast.makeText(this, "Viewing payment details of " + username, Toast.LENGTH_SHORT).show());

        btnFeatureLayout.addView(btnViewComplaints);
        btnFeatureLayout.addView(btnSendReminder);
        btnFeatureLayout.addView(btnViewPayment);

        // Add all to card
        card.addView(tvInfo);
        card.addView(tvStatus);
        card.addView(btnTopLayout);
        card.addView(btnFeatureLayout);

        return card;
    }

    private Button createStyledButton(String text, int colorRes) {
        Button btn = new Button(this);
        btn.setText(text);
        btn.setTextColor(getResources().getColor(android.R.color.white));
        btn.setBackgroundTintList(getResources().getColorStateList(colorRes, null));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1);
        lp.setMargins(8, 5, 8, 5);
        btn.setLayoutParams(lp);
        return btn;
    }

    private void deleteUser(String consumerNumber, View cardView) {
        new AlertDialog.Builder(this)
                .setTitle("Delete User")
                .setMessage("Are you sure you want to delete this user?")
                .setPositiveButton("Yes", (dialog, which) -> {
                    db.collection("UserProfiles").document(consumerNumber)
                            .delete()
                            .addOnSuccessListener(aVoid -> {
                                Toast.makeText(this, "✅ User deleted successfully!", Toast.LENGTH_SHORT).show();
                                containerUsers.removeView(cardView);
                            })
                            .addOnFailureListener(e ->
                                    Toast.makeText(this, "❌ Failed to delete user: " + e.getMessage(), Toast.LENGTH_SHORT).show()
                            );
                })
                .setNegativeButton("No", null)
                .show();
    }

    private void updateUserInfo(String consumerNumber) {
        EditText input = new EditText(this);
        input.setHint("Enter Payment Status (Paid / Pending)");
        input.setInputType(InputType.TYPE_CLASS_TEXT);

        new AlertDialog.Builder(this)
                .setTitle("Update Payment Status")
                .setView(input)
                .setPositiveButton("Update", (dialog, which) -> {
                    String status = input.getText().toString().trim();
                    if (status.isEmpty()) {
                        Toast.makeText(this, "Enter a valid status!", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    Map<String, Object> update = new HashMap<>();
                    update.put("paymentStatus", status);

                    db.collection("UserProfiles").document(consumerNumber)
                            .update(update)
                            .addOnSuccessListener(aVoid -> {
                                Toast.makeText(this, "✅ Payment status updated!", Toast.LENGTH_SHORT).show();
                                loadAllUsers(); // refresh
                            })
                            .addOnFailureListener(e ->
                                    Toast.makeText(this, "❌ Failed to update: " + e.getMessage(), Toast.LENGTH_SHORT).show()
                            );
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void sendPaymentReminder(String username, String contact, String consumerNumber, String paymentStatus) {
        if (paymentStatus != null && paymentStatus.equalsIgnoreCase("Paid")) {
            Toast.makeText(this, username + " has already paid the bill.", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "📩 Reminder sent to " + username + " (Consumer No: " + consumerNumber + ")", Toast.LENGTH_SHORT).show();
        }
    }
}
