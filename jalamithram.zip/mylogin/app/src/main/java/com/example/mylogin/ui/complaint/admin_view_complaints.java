//package com.example.mylogin.ui.complaint;
//
//
//import android.os.Bundle;
//import android.view.LayoutInflater;
//import android.view.View;
//import android.widget.Button;
//import android.widget.EditText;
//import android.widget.LinearLayout;
//import android.widget.TextView;
//import android.widget.Toast;
//
//import androidx.appcompat.app.AlertDialog;
//import androidx.appcompat.app.AppCompatActivity;
//
//import com.example.mylogin.R;
//import com.google.firebase.firestore.FirebaseFirestore;
//import com.google.firebase.firestore.QueryDocumentSnapshot;
//
//public class admin_view_complaints extends AppCompatActivity {
//
//    LinearLayout containerComplaints;
//    FirebaseFirestore db;
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_admin_view_complaint);
//
//        db = FirebaseFirestore.getInstance();
//        containerComplaints = findViewById(R.id.containerComplaints);
//
//        loadComplaints();
//    }
//
//    private void loadComplaints() {
//        // Example: if you want to filter by admin id or zone, use a Firestore query
//        db.collection("complaints")
//                //.whereEqualTo("assignedAdminId", currentAdminId) // optional filter
//                .get()
//                .addOnSuccessListener(querySnapshot -> {
//                    containerComplaints.removeAllViews();
//                    LayoutInflater inflater = LayoutInflater.from(this);
//
//                    for (QueryDocumentSnapshot doc : querySnapshot) {
//                        View card = inflater.inflate(R.layout.activity_item_admin_complaint, containerComplaints, false);
//
//                        TextView tvConsumer = card.findViewById(R.id.tvConsumerNumber);
//                        TextView tvUsername = card.findViewById(R.id.tvUsername);
//                        TextView tvType = card.findViewById(R.id.tvComplaintType);
//                        TextView tvText = card.findViewById(R.id.tvComplaintText);
//                        TextView tvDate = card.findViewById(R.id.tvDate);
//                        TextView tvReply = card.findViewById(R.id.tvAdminReply);
//                        Button btnReply = card.findViewById(R.id.btnReply);
//
//                        tvConsumer.setText("Consumer: " + doc.getString("consumerNumber"));
//                        tvUsername.setText("Username: " + doc.getString("username"));
//                        tvType.setText("Type: " + doc.getString("complaintType"));
//                        tvText.setText("Complaint: " + doc.getString("complaintText"));
//                        tvDate.setText("Date: " + doc.getString("date"));
//                        tvReply.setText("Reply: " + doc.getString("adminReply"));
//
//                        btnReply.setOnClickListener(v -> showReplyDialog(doc.getId(), doc.getString("adminReply")));
//
//                        containerComplaints.addView(card);
//                    }
//                })
//                .addOnFailureListener(e ->
//                        Toast.makeText(this, "Error loading complaints", Toast.LENGTH_SHORT).show());
//    }
//
//    private void showReplyDialog(final String docId, String oldReply) {
//        AlertDialog.Builder builder = new AlertDialog.Builder(this);
//        builder.setTitle("Reply to Complaint");
//
//        View dialogView = getLayoutInflater().inflate(R.layout.activity_dialog_admin_reply, null);
//        final EditText edtReply = dialogView.findViewById(R.id.edtAdminReply);
//        edtReply.setText(oldReply != null ? oldReply : "");
//
//        builder.setView(dialogView);
//        builder.setPositiveButton("Submit", (dialog, which) -> {
//            String reply = edtReply.getText().toString().trim();
//            if (!reply.isEmpty()) {
//                db.collection("complaints").document(docId)
//                        .update("adminReply", reply, "status", "Replied")
//                        .addOnSuccessListener(aVoid ->
//                                Toast.makeText(this, "Reply sent successfully", Toast.LENGTH_SHORT).show())
//                        .addOnFailureListener(e ->
//                                Toast.makeText(this, "Failed to send reply", Toast.LENGTH_SHORT).show());
//            }
//        });
//
//        builder.setNegativeButton("Cancel", null);
//        builder.show();
//    }
//}
