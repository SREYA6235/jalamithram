package com.example.mylogin;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.firestore.FirebaseFirestore;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

public class updatewatershedule extends AppCompatActivity {

    private EditText editTextAreaUpdate, editTextDateUpdate, editTextArrivalUpdate, editTextClosingUpdate;
    private Button buttonSaveUpdate, buttonCancelUpdate;

    private String scheduleId; // Firestore doc ID
    private FirebaseFirestore db;
    private Calendar calendar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_updatewatershedule);

        db = FirebaseFirestore.getInstance();
        calendar = Calendar.getInstance();

        // Bind views
        editTextAreaUpdate = findViewById(R.id.editTextAreaUpdate);
        editTextDateUpdate = findViewById(R.id.editTextDateUpdate);
        editTextArrivalUpdate = findViewById(R.id.editTextArrivalUpdate);
        editTextClosingUpdate = findViewById(R.id.editTextClosingUpdate);
        buttonSaveUpdate = findViewById(R.id.buttonSaveUpdate);
        buttonCancelUpdate = findViewById(R.id.buttonCancelUpdate);

        // Get data from intent
        if (getIntent() != null) {
            scheduleId = getIntent().getStringExtra("id");
            editTextAreaUpdate.setText(getIntent().getStringExtra("area"));
            editTextDateUpdate.setText(getIntent().getStringExtra("date"));
            editTextArrivalUpdate.setText(getIntent().getStringExtra("arrival"));
            editTextClosingUpdate.setText(getIntent().getStringExtra("closing"));
        }

        // Date Picker
        editTextDateUpdate.setOnClickListener(v -> {
            DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                    (view, year, month, dayOfMonth) ->
                            editTextDateUpdate.setText(dayOfMonth + "/" + (month + 1) + "/" + year),
                    calendar.get(Calendar.YEAR),
                    calendar.get(Calendar.MONTH),
                    calendar.get(Calendar.DAY_OF_MONTH));
            datePickerDialog.show();
        });

        // Time Pickers
        editTextArrivalUpdate.setOnClickListener(v -> showTimePicker(editTextArrivalUpdate));
        editTextClosingUpdate.setOnClickListener(v -> showTimePicker(editTextClosingUpdate));

        // Save Update
        buttonSaveUpdate.setOnClickListener(v -> updateSchedule());

        // Cancel Update
        buttonCancelUpdate.setOnClickListener(v -> finish());
    }

    private void showTimePicker(EditText editText) {
        TimePickerDialog timePickerDialog = new TimePickerDialog(this,
                (view, hourOfDay, minute) ->
                        editText.setText(String.format("%02d:%02d", hourOfDay, minute)),
                12, 0, true);
        timePickerDialog.show();
    }

    private void updateSchedule() {
        String area = editTextAreaUpdate.getText().toString().trim();
        String date = editTextDateUpdate.getText().toString().trim();
        String arrival = editTextArrivalUpdate.getText().toString().trim();
        String closing = editTextClosingUpdate.getText().toString().trim();

        if (area.isEmpty() || date.isEmpty() || arrival.isEmpty() || closing.isEmpty()) {
            Toast.makeText(this, "Fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        Map<String, Object> updated = new HashMap<>();
        updated.put("area", area);
        updated.put("date", date);
        updated.put("arrivalTime", arrival);
        updated.put("closingTime", closing);

        db.collection("waterSchedules").document(scheduleId)
                .update(updated)
                .addOnSuccessListener(aVoid -> {
                    Toast.makeText(this, "Schedule updated successfully", Toast.LENGTH_SHORT).show();
                    finish();
                })
                .addOnFailureListener(e ->
                        Toast.makeText(this, "Update failed", Toast.LENGTH_SHORT).show());
    }
}
