package com.example.mylogin;

public class Reminder {
    private String consumerNumber, username, message;
    public Reminder() { }
    public Reminder(String consumerNumber, String username, String message) {
        this.consumerNumber = consumerNumber;
        this.username = username;
        this.message = message;
    }
    // getters
}
