package com.example.mylogin;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class AdminPaymentFragment extends Fragment {

    RecyclerView rvAdminPayments;
    AdminPaymentAdapter adapter;
    List<payment> allPayments;
    DatabaseReference dbRef;
    Spinner spinnerMonth;
    Button btnPaid, btnUnpaid;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_admin_payment, container, false);

        rvAdminPayments = view.findViewById(R.id.rvAdminPayments);
        rvAdminPayments.setLayoutManager(new LinearLayoutManager(getContext()));

        spinnerMonth = view.findViewById(R.id.spinnerMonth);
        btnPaid = view.findViewById(R.id.btnPaid);
        btnUnpaid = view.findViewById(R.id.btnUnpaid);

        allPayments = new ArrayList<>();
        adapter = new AdminPaymentAdapter(allPayments, getContext(), false);
        rvAdminPayments.setAdapter(adapter);

        dbRef = FirebaseDatabase.getInstance().getReference("WaterBills");

        setupMonthSpinner();
        loadPayments();

        btnPaid.setOnClickListener(v -> filterByStatus("Paid"));
        btnUnpaid.setOnClickListener(v -> filterByStatus("Pending"));

        return view;
    }

    private void setupMonthSpinner() {
        List<String> months = new ArrayList<>();
        Calendar cal = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat("MM-yyyy");
        for (int i = 0; i < 12; i++) {
            months.add(sdf.format(cal.getTime()));
            cal.add(Calendar.MONTH, -1);
        }
        ArrayAdapter<String> adapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_spinner_item, months);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerMonth.setAdapter(adapter);
    }

    private void loadPayments() {
        // Step 1: Load all users
        FirebaseFirestore.getInstance().collection("UserProfiles")
                .get()
                .addOnSuccessListener(userQuery -> {
                    List<UserProfile> allUsers = new ArrayList<>();
                    for (DocumentSnapshot doc : userQuery.getDocuments()) {
                        UserProfile user = doc.toObject(UserProfile.class);
                        if (user != null) allUsers.add(user);
                    }

                    // Step 2: Load all bills
                    dbRef.addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            allPayments.clear();

                            // Add all existing bills
                            for (DataSnapshot snap : snapshot.getChildren()) {
                                payment bill = snap.getValue(payment.class);
                                if (bill != null) allPayments.add(bill);
                            }

                            // Add unpaid entries for selected month
                            String selectedMonth = (String) spinnerMonth.getSelectedItem();
                            for (UserProfile user : allUsers) {
                                boolean hasBill = false;
                                for (payment bill : allPayments) {
                                    if (bill.getConsumerNumber().equals(user.getConsumerNumber())) {
                                        try {
                                            String billMonth = new SimpleDateFormat("MM-yyyy")
                                                    .format(new SimpleDateFormat("dd-MM-yyyy").parse(bill.getBillDate()));
                                            if (billMonth.equals(selectedMonth)) {
                                                hasBill = true;
                                                break;
                                            }
                                        } catch (Exception e) { e.printStackTrace(); }
                                    }
                                }

                                if (!hasBill) {
                                    payment pending = new payment();
                                    pending.setUsername(user.getUsername());
                                    pending.setConsumerNumber(user.getConsumerNumber());
                                    pending.setPhoneNumber(user.getContact()); // Correct field for reminder
                                    pending.setStatus("Pending");
                                    pending.setBillAmount("Pending");
                                    pending.setBillDate(""); // no paid date
                                    allPayments.add(pending);
                                }
                            }

                            filterByStatus("Paid"); // default view
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {
                            Toast.makeText(getContext(), "Failed to load payments: " + error.getMessage(), Toast.LENGTH_LONG).show();
                        }
                    });
                });
    }

    private void filterByStatus(String status) {
        String selectedMonth = (String) spinnerMonth.getSelectedItem();
        List<payment> filtered = new ArrayList<>();

        for (payment bill : allPayments) {
            if (bill.getStatus() != null && bill.getStatus().equalsIgnoreCase(status)) {
                try {
                    String billMonth = (bill.getBillDate() != null && !bill.getBillDate().isEmpty())
                            ? new SimpleDateFormat("MM-yyyy").format(new SimpleDateFormat("dd-MM-yyyy").parse(bill.getBillDate()))
                            : selectedMonth; // treat unpaid as current month
                    if (billMonth.equals(selectedMonth)) filtered.add(bill);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }

        // Pass boolean true if filtering unpaid to show reminder button
        adapter = new AdminPaymentAdapter(filtered, getContext(), status.equalsIgnoreCase("Pending"));
        rvAdminPayments.setAdapter(adapter);
    }
}
