package com.example.mylogin;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class item_schedule extends AppCompatActivity {

    private TextView textViewArea, textViewDate, textViewArrival, textViewClosing;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_schedule);

        // Bind Views
        textViewArea = findViewById(R.id.textViewArea);
        textViewDate = findViewById(R.id.textViewDate);
        textViewArrival = findViewById(R.id.textViewArrival);
        textViewClosing = findViewById(R.id.textViewClosing);

        // Get values from Intent
        Intent intent = getIntent();
        if (intent != null) {
            String area = intent.getStringExtra("area");
            String date = intent.getStringExtra("date");
            String arrival = intent.getStringExtra("arrival");
            String closing = intent.getStringExtra("closing");

            // Set text with null safety
            textViewArea.setText("Area: " + (area != null ? area : "N/A"));
            textViewDate.setText("Date: " + (date != null ? date : "N/A"));
            textViewArrival.setText("Arrival: " + (arrival != null ? arrival : "N/A"));
            textViewClosing.setText("Closing: " + (closing != null ? closing : "N/A"));
        }
    }
}
