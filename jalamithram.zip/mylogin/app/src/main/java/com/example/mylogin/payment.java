package com.example.mylogin;
public class payment {
    private String username, phoneNumber, consumerNumber, meterReading;
    private String billAmount, billDate, dueDate, paymentId, status;
    private String meterImageBase64;

    // Default constructor
    public payment() { }

    // Getters
    public String getUsername() { return username; }
    public String getPhoneNumber() { return phoneNumber; }
    public String getConsumerNumber() { return consumerNumber; }
    public String getMeterReading() { return meterReading; }
    public String getBillAmount() { return billAmount; }
    public String getBillDate() { return billDate; }
    public String getDueDate() { return dueDate; }
    public String getPaymentId() { return paymentId; }
    public String getStatus() { return status; }
    public String getMeterImageBase64() { return meterImageBase64; }

    // ✅ Setters
    public void setUsername(String username) { this.username = username; }
    public void setPhoneNumber(String phoneNumber) { this.phoneNumber = phoneNumber; }
    public void setConsumerNumber(String consumerNumber) { this.consumerNumber = consumerNumber; }
    public void setMeterReading(String meterReading) { this.meterReading = meterReading; }
    public void setBillAmount(String billAmount) { this.billAmount = billAmount; }
    public void setBillDate(String billDate) { this.billDate = billDate; }
    public void setDueDate(String dueDate) { this.dueDate = dueDate; }
    public void setPaymentId(String paymentId) { this.paymentId = paymentId; }
    public void setStatus(String status) { this.status = status; }
    public void setMeterImageBase64(String meterImageBase64) { this.meterImageBase64 = meterImageBase64; }
}
