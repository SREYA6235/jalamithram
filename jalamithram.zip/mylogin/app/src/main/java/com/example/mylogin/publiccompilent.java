package com.example.mylogin;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class publiccompilent extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        TextView complaint=(TextView) findViewById(R.id.textView3);
        Button button2=(Button) findViewById(R.id.button2);
        EditText com=(EditText) findViewById(R.id.editTextTextMultiLine);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {


            }

        });

      /*  EdgeToEdge.enable(this);
        setContentView(R.layout.activity_publiccompilent);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });*/
    }
}