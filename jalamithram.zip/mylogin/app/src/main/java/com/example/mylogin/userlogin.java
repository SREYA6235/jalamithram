package com.example.mylogin;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

public class userlogin extends AppCompatActivity {

    private EditText edtConsumerNumber, edtPhoneNumber;
    private Button btnLogin;
    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_userlogin);

        edtConsumerNumber = findViewById(R.id.editConsumerNumber);
        edtPhoneNumber = findViewById(R.id.editPhoneNumber);
        btnLogin = findViewById(R.id.btnLogin);

        db = FirebaseFirestore.getInstance();

        btnLogin.setOnClickListener(v -> {
            String consumerNumber = edtConsumerNumber.getText().toString().trim();
            String phoneNumber = edtPhoneNumber.getText().toString().trim();

            if (consumerNumber.isEmpty() || phoneNumber.isEmpty()) {
                Toast.makeText(userlogin.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            Log.d("FirestoreLogin", "Checking for user: " + consumerNumber + " - " + phoneNumber);

            db.collection("UserProfiles")
                    .whereEqualTo("consumerNumber", consumerNumber)
                    .whereEqualTo("contact", phoneNumber) // ✅ Make sure Firestore field is 'contact'
                    .get()
                    .addOnSuccessListener(queryDocumentSnapshots -> {
                        if (!queryDocumentSnapshots.isEmpty()) {
                            for (QueryDocumentSnapshot document : queryDocumentSnapshots) {
                                Log.d("FirestoreLogin", "User found: " + document.getData());
                                Toast.makeText(userlogin.this, "✅ Login Successful", Toast.LENGTH_SHORT).show();

                                // ✅ Fetch username safely
                                String username = document.getString("username");
                                if (username == null || username.trim().isEmpty()) {
                                    username = "User";
                                }

                                // ✅ Save session globally (optional but helps later)
                                UserSession.consumerNumber = consumerNumber;
                                UserSession.phoneNumber = phoneNumber;
                                UserSession.username = username;

                                // ✅ Send all user info to homepage
                                Intent intent = new Intent(userlogin.this, user_homepage.class);
                                intent.putExtra("consumerNumber", consumerNumber);
                                intent.putExtra("phoneNumber", phoneNumber);
                                intent.putExtra("username", username);
                                startActivity(intent);
                                finish();
                                return;
                            }
                        } else {
                            Log.w("FirestoreLogin", "No matching user found");
                            Toast.makeText(userlogin.this, "❌ User not found. Please check details.", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .addOnFailureListener(e -> {
                        Log.e("FirestoreLogin", "Error fetching data", e);
                        Toast.makeText(userlogin.this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    });
        });
    }
}
