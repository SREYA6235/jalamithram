package com.example.mylogin;
import android.os.Bundle;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class paymenthistory extends AppCompatActivity {

    RecyclerView rvPaymentHistory;
    PaymentHistoryAdapter adapter;
    List<payment> paymentList;

    DatabaseReference dbRef;
    String consumerNumber = ""; // User-specific

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_paymenthistory);

        rvPaymentHistory = findViewById(R.id.rvPaymentHistory);
        rvPaymentHistory.setLayoutManager(new LinearLayoutManager(this));
        paymentList = new ArrayList<>();
        adapter = new PaymentHistoryAdapter(paymentList);
        rvPaymentHistory.setAdapter(adapter);

        // Get user details from intent
        consumerNumber = getIntent().getStringExtra("consumerNumber");

        dbRef = FirebaseDatabase.getInstance().getReference("WaterBills");

        loadPaymentHistory();
    }

    private void loadPaymentHistory() {
        dbRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                paymentList.clear();
                for (DataSnapshot billSnap : snapshot.getChildren()) {
                    payment bill = billSnap.getValue(payment.class);
                    if (bill != null) {
                        // Show either current user bills or all bills if admin
                        if (consumerNumber != null && !consumerNumber.isEmpty()) {
                            if (bill.getConsumerNumber().equals(consumerNumber)) {
                                paymentList.add(bill);
                            }
                        } else {
                            // Admin view: add all
                            paymentList.add(bill);
                        }
                    }
                }
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(paymenthistory.this, "Failed to load bills: " + error.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }
}
