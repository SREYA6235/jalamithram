//package com.example.mylogin.ui.profile;
//
//import android.os.Bundle;
//
//import androidx.fragment.app.Fragment;
//
//import android.view.LayoutInflater;
//import android.view.View;
//import android.view.ViewGroup;
//
//import com.example.mylogin.R;
//
///**
// * A simple {@link Fragment} subclass.
// * Use the {@link profileFragment#newInstance} factory method to
// * create an instance of this fragment.
// */
//public class profileFragment extends Fragment {
//
//    // TODO: Rename parameter arguments, choose names that match
//    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
//    private static final String ARG_PARAM1 = "param1";
//    private static final String ARG_PARAM2 = "param2";
//
//    // TODO: Rename and change types of parameters
//    private String mParam1;
//    private String mParam2;
//
//    public profileFragment() {
//        // Required empty public constructor
//    }
//
//    /**
//     * Use this factory method to create a new instance of
//     * this fragment using the provided parameters.
//     *
//     * @param param1 Parameter 1.
//     * @param param2 Parameter 2.
//     * @return A new instance of fragment profileFragment.
//     */
//    // TODO: Rename and change types and number of parameters
//    public static profileFragment newInstance(String param1, String param2) {
//        profileFragment fragment = new profileFragment();
//        Bundle args = new Bundle();
//        args.putString(ARG_PARAM1, param1);
//        args.putString(ARG_PARAM2, param2);
//        fragment.setArguments(args);
//        return fragment;
//    }
//
//    @Override
//    public void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        if (getArguments() != null) {
//            mParam1 = getArguments().getString(ARG_PARAM1);
//            mParam2 = getArguments().getString(ARG_PARAM2);
//        }
//    }
//
//    @Override
//    public View onCreateView(LayoutInflater inflater, ViewGroup container,
//                             Bundle savedInstanceState) {
//        // Inflate the layout for this fragment
//        return inflater.inflate(R.layout.fragment_profile, container, false);
//    }
//}
package com.example.mylogin.ui.profile;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.mylogin.R;
import com.example.mylogin.ViewAllUsersActivity;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class profileFragment extends Fragment {

    private EditText editName, editPhone, editConsumer, editCardType, editAddress,
            editArea, editConnectionType, editConnectionDate;
    private Button btnAddProfile, btnViewProfiles;
    private FirebaseFirestore db;

    public profileFragment() {}

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_profile, container, false);

        db = FirebaseFirestore.getInstance();

        editName = view.findViewById(R.id.editName);
        editPhone = view.findViewById(R.id.editPhone);
        editConsumer = view.findViewById(R.id.editConsumer);
        editCardType = view.findViewById(R.id.editCardType);
        editAddress = view.findViewById(R.id.editAddress);
        editArea = view.findViewById(R.id.editArea);
        editConnectionType = view.findViewById(R.id.editConnectionType);
        editConnectionDate = view.findViewById(R.id.editConnectionDate);

        btnAddProfile = view.findViewById(R.id.btnAddProfile);
        btnViewProfiles = view.findViewById(R.id.btnViewProfiles);

        btnAddProfile.setOnClickListener(v -> addUserProfile());

        btnViewProfiles.setOnClickListener(v -> {
            Toast.makeText(getContext(), "Opening all profiles...", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(getActivity(), ViewAllUsersActivity.class);
            startActivity(intent);
        });


        return view;
    }

    private void addUserProfile() {
        String name = editName.getText().toString().trim();
        String phone = editPhone.getText().toString().trim();
        String consumer = editConsumer.getText().toString().trim();
        String cardType = editCardType.getText().toString().trim();
        String address = editAddress.getText().toString().trim();
        String area = editArea.getText().toString().trim();
        String connectionType = editConnectionType.getText().toString().trim();
        String connectionDate = editConnectionDate.getText().toString().trim();

        if (TextUtils.isEmpty(name) || TextUtils.isEmpty(phone) || TextUtils.isEmpty(consumer)
                || TextUtils.isEmpty(cardType) || TextUtils.isEmpty(address)
                || TextUtils.isEmpty(area) || TextUtils.isEmpty(connectionType)
                || TextUtils.isEmpty(connectionDate)) {
            Toast.makeText(getContext(), "Please fill in all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        Map<String, Object> user = new HashMap<>();
        user.put("username", name);
        user.put("contact", phone);
        user.put("consumerNumber", consumer);
        user.put("cardType", cardType);
        user.put("address", address);
        user.put("area", area);
        user.put("connectionType", connectionType);
        user.put("connectionDate", connectionDate);
        user.put("currentBill", "0");
        user.put("paymentStatus", "Pending");

        DocumentReference userRef = db.collection("UserProfiles").document(consumer);
        userRef.set(user)
                .addOnSuccessListener(aVoid -> {
                    Toast.makeText(getContext(), "✅ User profile added successfully!", Toast.LENGTH_SHORT).show();
                    clearFields();
                })
                .addOnFailureListener(e ->
                        Toast.makeText(getContext(), "❌ Failed: " + e.getMessage(), Toast.LENGTH_SHORT).show()
                );
    }

    private void clearFields() {
        editName.setText("");
        editPhone.setText("");
        editConsumer.setText("");
        editCardType.setText("");
        editAddress.setText("");
        editArea.setText("");
        editConnectionType.setText("");
        editConnectionDate.setText("");
    }
}
