package com.example.mylogin.ui.complaint;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import com.example.mylogin.R;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

public class admin_complaint_view extends Fragment {

    private LinearLayout containerComplaints;
    private FirebaseFirestore db;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_admin_complaint_view, container, false);

        db = FirebaseFirestore.getInstance();
        containerComplaints = root.findViewById(R.id.containerComplaints);

        loadComplaints(inflater);
        return root;
    }

    private void loadComplaints(LayoutInflater inflater) {
        db.collection("complaints")
                .get()
                .addOnSuccessListener(querySnapshot -> {
                    containerComplaints.removeAllViews();
                    if (querySnapshot.isEmpty()) {
                        Toast.makeText(getContext(), "No complaints found", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    for (QueryDocumentSnapshot doc : querySnapshot) {
                        View card = inflater.inflate(R.layout.item_admin_complaint, containerComplaints, false);

                        TextView tvConsumer = card.findViewById(R.id.tvConsumerNumber);
                        TextView tvUsername = card.findViewById(R.id.tvUsername);
                        TextView tvType = card.findViewById(R.id.tvComplaintType);
                        TextView tvText = card.findViewById(R.id.tvComplaintText);
                        TextView tvDate = card.findViewById(R.id.tvDate);
                        TextView tvReply = card.findViewById(R.id.tvAdminReply);
                        Button btnReply = card.findViewById(R.id.btnReply);

                        // Get data safely
                        String consumer = doc.getString("consumerNumber");
                        String username = doc.getString("username");  // may be null
                        String type = doc.getString("complaintType");
                        String text = doc.getString("complaintText");
                        String date = doc.getString("date");
                        String reply = doc.getString("adminReply");

                        tvConsumer.setText("Consumer: " + (consumer != null ? consumer : "N/A"));
                        tvType.setText("Type: " + (type != null ? type : "N/A"));
                        tvText.setText("Complaint: " + (text != null ? text : "N/A"));
                        tvDate.setText("Date: " + (date != null ? date : "N/A"));
                        tvReply.setText("Reply: " + (reply != null ? reply : "No reply yet"));

                        // 🔹 If username is missing, fetch it from UserProfiles using consumerNumber
                        if (username == null || username.isEmpty()) {
                            if (consumer != null && !consumer.isEmpty()) {
                                db.collection("UserProfiles")
                                        .document(consumer)
                                        .get()
                                        .addOnSuccessListener(userDoc -> {
                                            if (userDoc.exists()) {
                                                String fetchedUsername = userDoc.getString("username");
                                                tvUsername.setText("Username: " +
                                                        (fetchedUsername != null ? fetchedUsername : "Unknown"));
                                            } else {
                                                // if document name isn't consumer number, try searching by field
                                                db.collection("UserProfiles")
                                                        .whereEqualTo("consumerNumber", consumer)
                                                        .get()
                                                        .addOnSuccessListener(q -> {
                                                            if (!q.isEmpty()) {
                                                                String fetchedUsername = q.getDocuments()
                                                                        .get(0).getString("username");
                                                                tvUsername.setText("Username: " +
                                                                        (fetchedUsername != null ? fetchedUsername : "Unknown"));
                                                            } else {
                                                                tvUsername.setText("Username: Unknown");
                                                            }
                                                        })
                                                        .addOnFailureListener(e ->
                                                                tvUsername.setText("Username: Unknown"));
                                            }
                                        })
                                        .addOnFailureListener(e ->
                                                tvUsername.setText("Username: Unknown"));
                            } else {
                                tvUsername.setText("Username: Unknown");
                            }
                        } else {
                            tvUsername.setText("Username: " + username);
                        }

                        btnReply.setOnClickListener(v -> showReplyDialog(doc.getId(), reply));
                        containerComplaints.addView(card);
                    }
                })
                .addOnFailureListener(e ->
                        Toast.makeText(getContext(), "Error loading complaints", Toast.LENGTH_SHORT).show());
    }

    private void showReplyDialog(final String docId, String oldReply) {
        AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
        builder.setTitle("Reply to Complaint");

        View dialogView = getLayoutInflater().inflate(R.layout.dialog_admin_reply, null);
        final EditText edtReply = dialogView.findViewById(R.id.edtAdminReply);
        edtReply.setText(oldReply != null ? oldReply : "");

        builder.setView(dialogView);
        builder.setPositiveButton("Submit", (dialog, which) -> {
            String reply = edtReply.getText().toString().trim();
            if (!reply.isEmpty()) {
                db.collection("complaints").document(docId)
                        .update("adminReply", reply, "status", "Replied")
                        .addOnSuccessListener(aVoid ->
                                Toast.makeText(getContext(), "Reply sent successfully", Toast.LENGTH_SHORT).show())
                        .addOnFailureListener(e ->
                                Toast.makeText(getContext(), "Failed to send reply", Toast.LENGTH_SHORT).show());
            } else {
                Toast.makeText(getContext(), "Reply cannot be empty", Toast.LENGTH_SHORT).show();
            }
        });

        builder.setNegativeButton("Cancel", null);
        builder.show();
    }
}
