package com.example.mylogin;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.*;
import com.google.firebase.auth.FirebaseAuth;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;

public class alogin extends AppCompatActivity {

    EditText email, password;
    Button loginBtn;
    TextView createAccount;
    FirebaseAuth auth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alogin); // ✅ Ensure this XML name matches your file name

        // ✅ Initialize Firebase
        auth = FirebaseAuth.getInstance();

        // ✅ Link UI elements
        email = findViewById(R.id.email);
        password = findViewById(R.id.password);
        loginBtn = findViewById(R.id.loginBtn);
        createAccount = findViewById(R.id.createAccount);

        // ✅ Button actions
        loginBtn.setOnClickListener(v -> loginUser());

        createAccount.setOnClickListener(v -> {
            Intent intent = new Intent(alogin.this, asignup.class);
            startActivity(intent);
        });
    }

    private void loginUser() {
        String userEmail = email.getText().toString().trim();
        String userPass = password.getText().toString().trim();

        if (TextUtils.isEmpty(userEmail)) {
            email.setError("Email is required");
            email.requestFocus();
            return;
        }

        if (TextUtils.isEmpty(userPass)) {
            password.setError("Password is required");
            password.requestFocus();
            return;
        }

        // ✅ Firebase login
        auth.signInWithEmailAndPassword(userEmail, userPass)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        Toast.makeText(alogin.this, "Login successful!", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(alogin.this, navigationbar.class));
                        finish();
                    } else {
                        Toast.makeText(alogin.this, "Error: " + task.getException().getMessage(), Toast.LENGTH_LONG).show();
                    }
                });
    }
}
